# Partition Playground

A scenario-driven adversary lab built on the Lab 03 network (`consensus/`). Each scenario file
describes the network conditions and the adversaries. The engine runs Lab 03's PoW gossip nodes
alongside Lab 03's Casper FFG state machine, and a dashboard shows what an operator would see.

```bash
pip install -r requirements.txt
python -m pytest -q                                  # 25 asserted scenario tests, ≈ 21 s
python -m playground.engine eclipse -o eclipse.jsonl # run one scenario, print its metrics
python -m playground.serve --port 8000               # dashboard: http://127.0.0.1:8000/
                                                     # live stream: /?live=eclipse&speed=20
python report/make_report.py                         # rebuild the PDF report from fresh runs
```

## What is in the repo

| Path | What it is |
|---|---|
| `consensus/` | **Lab 03, verbatim** (`chain`, `network`, `pos`, `pow`, `cli`). Pinned by `SHA256SUMS.json`; a test fails if anyone edits it. |
| `playground/engine.py` | Scenario engine. Contains `PlaygroundNetwork(Network)`, `PlaygroundNode(Node)`, the YAML loader, the timeline actions and the JSON event stream. |
| `playground/vclock.py` | Virtual-clock asyncio loop. Lab 03's `asyncio.sleep` latency and mining run in virtual time, so runs are deterministic and instant. |
| `playground/ffg.py` | `NodeBeacon(pos.BeaconState)`: one Lab 03 Casper FFG state per node, plus dedup, slashing evidence and justification proofs for gossip. |
| `playground/metrics.py` | Stale rate, reorg depth, convergence time, finality lag and conflicting finality, computed **from the event stream only**. |
| `playground/scenarios/*.yaml` | 9 scenarios. Each has a `description` and an `expect:` block that the tests assert. |
| `playground/serve.py`, `export.py` | Live server-sent-events stream, and recorded `.jsonl` files for the dashboard. |
| `dashboard/` | Static HTML/JS dashboard (no build step). Shows tips per node, branch divergence, reorg depth, orphan rate and an FFG finality-lag heatmap, plus alarms. |
| `tests/test_scenarios.py` | Asserted outcomes, determinism checks, Lab 03 reuse checks and unit tests. |
| `report/` | `partition_playground_report.pdf` (3 pages), `eclipse_demo.mp4` (2:26), and the generator script. |

## Scenarios and their asserted outcomes

| Scenario | Pathology | Asserted outcome (seeded, exact) |
|---|---|---|
| `partition_50_50` | 50/50 split, then heal | Both sides keep mining. The heal reorgs ≥ 5 blocks and the network converges within 120 s. Neither side finalises during the split. No conflicting finality. |
| `partition_70_30` | 70/30 split | Majority reorgs ≤ 2 and finalises every epoch. Minority's finality is frozen; it reorgs ≥ 5 and catches up via proofs. |
| `eclipse` | Two attackers take all of node9's peer slots | Payment to the victim reaches ≥ 6 confirmations, then drops to 0 (double spend). Victim reorgs ≥ 6. Victim's finality lag grows by 1 per epoch. |
| `high_latency` | Δ/T swept from 0.02 to 0.4 | Stale rate rises strictly and stays within 0.6–1.1× of 1 − e^(−Δ/T). |
| `orphan_rate` | Δ = 10 % of T | Stale rate 8.02 % is inside the documented band [7.0 %, 12.0 %] around 1 − e^(−0.1) = 9.52 %, and within 3σ of the refined 8.57 %. |
| `ffg_offline_40` | 40 % of stake offline | Leak starts at epoch 14, justification returns at 33 and finality at 34. These are exactly the epochs of a bare Lab 03 `BeaconState`. |
| `delayed_relay` | Bridge node holds relayed blocks for 4 s | Stale rate rises by ≥ 3 pp (7.2 % → 16.0 %). |
| `equivocation` *(stretch)* | Validator double-votes | Slashing evidence reaches all other honest nodes through gossip within 10 s, every view slashes, and finality continues. |
| `partition_long_ffg` | 55-epoch 50/50 split | The inactivity leak on both sides leads to conflicting finalised checkpoints, which the reorg reverts after the heal. |

**Band for the orphan-rate scenario.** 1 − e^(−0.1) assumes every other miner is racing. With 10 equal
miners, a miner never races its own block, which gives 1 − E[e^(−0.9Δ/T)] = 8.57 % (−1.0 pp). Sampling
noise is σ ≈ 0.46 pp at about 3,700 blocks. The band is 9.52 % ± 2.5 pp, i.e. the systematic offset
plus ±3σ. Across 8 seeds the measured rates were 7.4–8.9 %.

## Scenario format

```yaml
name: eclipse
seed: 21                     # everything derives from this
duration: 1100               # virtual seconds
block_time: 10               # mean NETWORK block interval
nodes: 10
peers_per_node: 3            # or "all" (full mesh); or give `topology:` adjacency explicitly
latency: 0.5                 # mean one-hop latency (Lab 03 jitter: U(0.5, 1.5) x latency)
links: [{a: node0, b: node1, latency: 2.0}]                # optional per-link override
adversaries: [{id: atk0, hash_power: 1.0, peers: 3}]
ffg: {epoch_length: 40}      # optional: run Casper FFG (one 32 ETH validator per honest node)
sweep: {latency: [0.2, 0.5]} # optional: run once per value
timeline:                    # actions at virtual times
  - {at: 100, eclipse: {victim: node9, attackers: [atk0, atk1]}}
  - {at: 700, end_eclipse: true}
expect: {...}                # documented outcome; asserted by tests
```

Actions: `partition` (explicit groups or `{split: [0.7, 0.3]}`), `heal`, `latency`, `eclipse`,
`end_eclipse`, `relay_delay`, `offline`, `online`, `stop_mining`, `tx`, `equivocate`. To add a
pathology, add one branch to `Simulation.do()` and a YAML file. Adversary behaviour lives in the
`PlaygroundNode` overrides.

## How Lab 03 is reused, and the four places the engine deviates

All gossip, fork choice, reconciliation, mining and FFG rules are inherited from Lab 03; the tests
assert method identity. The engine changes only how Lab 03 code is *run*:

1. **Virtual time.** Lab 03's asyncio code runs on `VirtualClockLoop`.
2. **Seeded miners.** Lab 03 seeds `Node._rng` from `hash(node_id)`, which Python randomises per
   process. The engine reseeds each node from the scenario seed instead. A test checks for
   byte-identical streams across `PYTHONHASHSEED` values.
3. **Non-blocking delivery.** Lab 03's `broadcast` awaits every delivery, which stalls the sender's
   mining and inbox for one hop. The engine schedules deliveries on the loop instead; reachability is
   still checked at send time.
4. **`Block.hash` memoised.** The hash is a pure function of a frozen header, so caching it changes
   no result; a test compares it against Lab 03's own computation. This makes the long runs 3.9× faster.

`NodeBeacon` adds only what one-view-per-node needs: dedup, incremental slashing detection with Lab
03's predicates, and justification proofs. In Ethereum the votes live on-chain; here they travel
with Lab 03's `getchain` reply. Every node verifies the proofs against its own balances.

## Dashboard

There are three ways to feed it:

- **Recorded file:** pick a scenario, or drop a `.jsonl` onto it (`python -m playground.export` refreshes `dashboard/data/`).
- **Live stream:** `/?live=<scenario>&speed=20` uses server-sent events from `playground/serve.py`.
- **Demo mode:** `/?mode=video&captions=eclipse` is the 16:9 layout used for the video, rebuilt by `node dashboard/record_demo.js`.

The colours follow a validated palette: three categorical slots for branches (checked all-pairs for
colour blindness in light and dark mode), a sequential ramp for finality lag, and reserved status
colours that always come with an icon and a label.

## CI

`.github/workflows/ci.yml` runs `timeout 60 python -m pytest`. The full suite takes about 21 s
locally. The two statistical tests, the latency sweep and the orphan-rate calibration, account for
about 14 s of that.
