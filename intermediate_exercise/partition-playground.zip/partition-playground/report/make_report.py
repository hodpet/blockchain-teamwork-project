"""Build report/partition_playground_report.pdf (<= 6 pages) from fresh, seeded scenario runs.

    python report/make_report.py

Every number and plot is recomputed here from the engine; nothing is typed by hand.
"""
from __future__ import annotations

import math
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.lib.units import mm  # noqa: E402
from reportlab.lib.fonts import addMapping  # noqa: E402
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402
from reportlab.platypus import (Image, KeepTogether, Paragraph, SimpleDocTemplate, Spacer,  # noqa: E402
                                Table, TableStyle)

from playground import metrics as M  # noqa: E402
from playground.engine import Scenario, run_scenario, run_sweep  # noqa: E402
from playground.ffg import predict_leak_recovery  # noqa: E402

BUILD = ROOT / "report" / "build"
BUILD.mkdir(parents=True, exist_ok=True)
OUT = ROOT / "report" / "partition_playground_report.pdf"

# dataviz reference palette (light): categorical slots 1-3, ink, grid
C1, C2, C3 = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, MUTED, GRID, AXIS = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 7.5, "axes.edgecolor": AXIS, "axes.linewidth": 0.8,
    "axes.labelcolor": INK2, "xtick.color": MUTED, "ytick.color": MUTED, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "legend.fontsize": 7, "axes.titlesize": 8, "axes.titleweight": "bold",
    "axes.titlecolor": INK, "lines.linewidth": 1.6, "lines.solid_capstyle": "round", "text.color": INK,
})


def shade(ax, t0, t1, label):
    ax.axvspan(t0, t1, color="#f0efec", zorder=0, lw=0)
    ax.text((t0 + t1) / 2, 0.04, label, transform=ax.get_xaxis_transform(), ha="center", va="bottom",
            fontsize=6.5, color=INK2)


def save(fig, name):
    path = BUILD / f"{name}.png"
    fig.savefig(path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return path


def snaps(res):
    return res.of("snapshot")


def group_series(res, groups):
    """Median height per group over time."""
    out = [[] for _ in groups]
    for s in snaps(res):
        for i, g in enumerate(groups):
            out[i].append((s["t"], statistics.median(s["heights"][n] for n in g)))
    return out


def ffg(res, node, field="finalized"):
    return [(e["epoch"], e[field]) for e in M.ffg_by_node(res.events)[node]]


def fork_depth(res, node, ref):
    """Blocks on `node`'s branch since it forked from `ref`'s chain, per snapshot (full hashes from registry)."""
    from playground import lab03_adapter as A
    full = {h[:10]: h for h in res.registry}
    sim_like = res  # registry walk
    out = []
    for s in snaps(res):
        a, b = full[s["tips"][node]], full[s["tips"][ref]]
        ba, bb = res.registry[a], res.registry[b]
        ha, hb = A.block_height(ba), A.block_height(bb)
        x, y = ba, bb
        while A.block_height(x) > A.block_height(y):
            x = res.registry[A.block_parent(x)]
        while A.block_height(y) > A.block_height(x):
            y = res.registry[A.block_parent(y)]
        while A.block_hash(x) != A.block_hash(y):
            x, y = res.registry[A.block_parent(x)], res.registry[A.block_parent(y)]
        out.append((s["t"], ha - A.block_height(x)))
        _ = (hb, sim_like)
    return out


def xy(points):
    return [p[0] for p in points], [p[1] for p in points]


facts: dict[str, object] = {}

# =========================================================================== 1. 50/50
r = run_scenario("partition_50_50")
tp, th = M.action_time(r.events, "partition"), M.action_time(r.events, "heal")
gA, gB = next(e for e in r.of("action") if e["kind"] == "partition")["groups"]
facts["p50"] = {
    "reorg": M.max_reorg_depth(r.events, t_from=th), "conv": M.convergence_time(r.events, th),
    "fin_frozen": ffg(r, gA[0])[int(tp // 40)][1], "fin_end": ffg(r, gA[0])[-1][1],
    "conflicts": len(M.conflicting_finality(r.events)), "dropped": r.events[-1]["dropped"],
    "hA": snaps(r)[int(th // 10) - 1]["heights"][gA[0]], "hB": snaps(r)[int(th // 10) - 1]["heights"][gB[0]],
    "h0": snaps(r)[int(tp // 10)]["heights"][gA[0]],
}
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 2.0))
for (pts, c, lab) in zip(group_series(r, [gA, gB]), (C1, C2), ("side A (5 nodes)", "side B (5 nodes)")):
    a1.plot(*xy(pts), color=c, label=lab)
shade(a1, tp, th, "partition")
a1.set_title("Chain height (median per side)")
a1.set_xlabel("time (s)")
a1.legend(loc="upper left")
for node, c, lab in ((gA[0], C1, "side A"), (gB[0], C2, "side B")):
    a2.plot(*xy(ffg(r, node)), color=c, label=lab, drawstyle="steps-post")
a2.axvspan(tp / 40, th / 40, color="#f0efec", zorder=0, lw=0)
a2.set_title("FFG finalised epoch")
a2.set_xlabel("epoch")
a2.legend(loc="upper left")
fig_p50 = save(fig, "p50")

# =========================================================================== 2. 70/30
r = run_scenario("partition_70_30")
tp, th = M.action_time(r.events, "partition"), M.action_time(r.events, "heal")
major, minor = next(e for e in r.of("action") if e["kind"] == "partition")["groups"]
facts["p70"] = {
    "major_reorg": M.max_reorg_depth(r.events, nodes=major), "minor_reorg": M.max_reorg_depth(r.events, nodes=minor),
    "major_fin_heal": dict(ffg(r, major[0]))[int(th // 40)], "minor_fin_heal": dict(ffg(r, minor[0]))[int(th // 40) - 1],
    "conflicts": len(M.conflicting_finality(r.events)),
}
fd = fork_depth(r, minor[0], major[0])
facts["p70"]["minor_branch"] = max(v for _, v in fd)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 2.0))
a1.plot(*xy(fd), color=C2, label="minority branch")
shade(a1, tp, th, "partition")
a1.set_title("Blocks on the minority branch since the fork")
a1.set_xlabel("time (s)")
a1.legend(loc="upper left")
for node, c, lab in ((major[0], C1, "70 % side"), (minor[0], C2, "30 % side")):
    a2.plot(*xy(ffg(r, node)), color=c, label=lab, drawstyle="steps-post")
a2.axvspan(tp / 40, th / 40, color="#f0efec", zorder=0, lw=0)
a2.set_title("FFG finalised epoch")
a2.set_xlabel("epoch")
a2.legend(loc="upper left")
fig_p70 = save(fig, "p70")

# =========================================================================== 3. eclipse
r = run_scenario("eclipse")
t0, t1 = M.action_time(r.events, "eclipse"), M.action_time(r.events, "end_eclipse")
cs = [s for s in snaps(r) if "conflicting_spend" in s.get("confs", {})]
pay = [(s["t"], s["confs"]["payment_to_victim"]["node9"]) for s in cs]
dbl = [(s["t"], s["confs"]["conflicting_spend"]["node0"]) for s in cs]
lag9 = [(e, e - f) for e, f in ffg(r, "node9")]
lag0 = [(e, e - f) for e, f in ffg(r, "node0")]
facts["ecl"] = {"pay_max": max(v for _, v in pay), "pay_end": pay[-1][1], "dbl_end": dbl[-1][1],
                "reorg": M.max_reorg_depth(r.events, nodes=["node9"]), "lag_max": max(v for _, v in lag9),
                "fin_after": dict(ffg(r, "node9"))[int(t1 // 40) + 1]}
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 2.0))
a1.plot(*xy(pay), color=C2, label="payment to victim, seen by node9")
a1.plot(*xy(dbl), color=C1, label="conflicting spend, seen by node0")
shade(a1, t0, t1, "eclipse")
a1.set_title("Confirmations")
a1.set_xlabel("time (s)")
a1.legend(loc="upper left")
a2.plot(*xy(lag0), color=C1, label="node0 (honest)")
a2.plot(*xy(lag9), color=C2, label="node9 (victim)")
a2.axvspan(t0 / 40, t1 / 40, color="#f0efec", zorder=0, lw=0)
a2.set_title("FFG finality lag (epochs)")
a2.set_xlabel("epoch")
a2.legend(loc="upper left")
fig_ecl = save(fig, "eclipse")

# =========================================================================== 4. latency + orphan calibration
sweep = run_sweep("high_latency")
pts = []
for p, rr in sweep:
    s = M.stale_rate(rr.events)
    pts.append((p["latency"] / 10.0, s["rate"], s["stderr"], s["mined"]))
cal = M.stale_rate(run_scenario("orphan_rate").events)
exp_cal = Scenario.load("orphan_rate").expect
facts["orph"] = {"rate": cal["rate"], "se": cal["stderr"], "n": cal["mined"], "band": exp_cal["band"],
                 "refined": exp_cal["refined_estimate"], "sweep": pts}
dr = run_scenario("delayed_relay")
dr0 = run_scenario("delayed_relay", timeline=[])
facts["relay"] = {"with": M.stale_rate(dr.events)["rate"], "without": M.stale_rate(dr0.events)["rate"]}

fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 2.1), gridspec_kw={"width_ratios": [1.5, 1]})
xs = [i / 1000 for i in range(0, 421)]
a1.plot(xs, [1 - math.exp(-x) for x in xs], color=MUTED, lw=1, label="1 − e^(−Δ/T)")
a1.plot(xs, [1 - math.exp(-0.9 * x) for x in xs], color=C3, lw=1.2, label="1 − e^(−0.9Δ/T)  (no self-race, n = 10)")
a1.errorbar([p[0] for p in pts], [p[1] for p in pts], yerr=[1.96 * p[2] for p in pts], fmt="o", ms=4,
            color=C1, ecolor=C1, elinewidth=1, capsize=2, label="measured (95 % CI)")
a1.errorbar([0.1], [cal["rate"]], yerr=[1.96 * cal["stderr"]], fmt="D", ms=4, color=C2, ecolor=C2,
            elinewidth=1, capsize=2, label=f"calibration run (n = {cal['mined']})")
a1.set_xlabel("propagation delay / block time  (Δ/T)")
a1.set_title("Stale (orphan) rate vs Δ/T")
a1.legend(loc="upper left", fontsize=6.3)
lo, hi = exp_cal["band"]
a2.axhspan(lo * 100, hi * 100, color="#eaf2fc", lw=0, label="documented band")
a2.axhline(100 * (1 - math.exp(-0.1)), color=MUTED, lw=1, label="analytic 9.52 %")
a2.errorbar([0], [cal["rate"] * 100], yerr=[1.96 * cal["stderr"] * 100], fmt="D", ms=4, color=C2,
            ecolor=C2, capsize=3, label="measured")
a2.set_xlim(-1, 1)
a2.set_xticks([])
a2.set_ylim(5, 13)
a2.set_ylabel("stale rate (%)")
a2.set_title("Δ = 0.1 T calibration")
a2.legend(loc="upper right", fontsize=6.3)
fig_lat = save(fig, "latency")

# =========================================================================== 5. FFG 40 % offline
r = run_scenario("ffg_offline_40")
pred = predict_leak_recovery(10, offline=[6, 7, 8, 9], first_offline_epoch=10)
n0 = M.ffg_by_node(r.events)["node0"]
online_share = [(e["epoch"], 100 * e["voting"] / e["active"]) for e in n0]
lag = [(e["epoch"], e["epoch"] - e["finalized"]) for e in n0]
hts = [(s["t"] / 40, s["heights"]["node0"]) for s in snaps(r)]
facts["ffg"] = {"pred": pred, "obs_j": min(e["epoch"] for e in n0 if e["epoch"] >= 10 and e["justified"] == e["epoch"]),
                "obs_f": min(e["epoch"] for e in n0 if e["epoch"] >= 10 and e["finalized"] > 8),
                "leak": min(e["epoch"] for e in n0 if e["leaking"]),
                "lag_max": max(v for _, v in lag), "h10": dict((int(t), h) for t, h in hts).get(10),
                "h33": dict((int(t), h) for t, h in hts).get(33)}
fig, (a1, a2, a3) = plt.subplots(1, 3, figsize=(7.2, 1.95))
a1.plot(*xy(lag), color=C1, drawstyle="steps-post")
a1.set_title("Finality lag (epochs)")
a1.set_xlabel("epoch")
a2.plot(*xy(online_share), color=C1)
a2.axhline(200 / 3, color=MUTED, lw=1)
a2.text(1, 200 / 3 + 1, "2/3 threshold", color=INK2, fontsize=6.5)
a2.set_title("Online share of active stake (%)")
a2.set_xlabel("epoch")
a3.plot(*xy(hts), color=C1)
a3.set_title("PoW height keeps growing")
a3.set_xlabel("epoch")
for ax in (a1, a2, a3):
    ax.axvspan(10, facts["ffg"]["obs_f"], color="#f0efec", zorder=0, lw=0)
    ax.axvline(pred["leak_starts"], color=MUTED, lw=0.8)
a1.text(pred["leak_starts"] + 0.5, max(v for _, v in lag) * 0.9, "leak starts", fontsize=6.5, color=INK2)
fig_ffg = save(fig, "ffg")

# =========================================================================== extras
r = run_scenario("equivocation")
t_eq = M.action_time(r.events, "equivocate")
arr = sorted(e["t"] - t_eq for e in r.of("slashing_evidence"))
facts["eq"] = {"n": len(arr), "first": arr[0], "last": arr[-1]}
r = run_scenario("partition_long_ffg")
conf = M.conflicting_finality(r.events)
rev = r.events[-1]["reverted_finality"]
facts["long"] = {"conflicts": len(conf), "first": conf[0][0] if conf else None,
                 "reverted_nodes": sorted(k for k, v in rev.items() if v), "reverted_epochs": next((v for v in rev.values() if v), [])}

# =========================================================================== PDF
_D = "/usr/share/fonts/truetype/dejavu/"
for name, fn in (("DV", "DejaVuSans.ttf"), ("DV-B", "DejaVuSans-Bold.ttf"), ("DV-I", "DejaVuSans-Oblique.ttf"),
                 ("DV-BI", "DejaVuSans-BoldOblique.ttf"), ("DVM", "DejaVuSansMono.ttf")):
    pdfmetrics.registerFont(TTFont(name, _D + fn))
addMapping("DV", 0, 0, "DV"); addMapping("DV", 1, 0, "DV-B"); addMapping("DV", 0, 1, "DV-I"); addMapping("DV", 1, 1, "DV-BI")
st = {
    "h1": ParagraphStyle("h1", fontName="DV-B", fontSize=14, leading=17, spaceAfter=2),
    "h2": ParagraphStyle("h2", fontName="DV-B", fontSize=10.5, leading=13, spaceBefore=7, spaceAfter=2,
                         textColor=colors.HexColor("#1c5cab")),
    "p": ParagraphStyle("p", fontName="DV", fontSize=8.1, leading=10.8, spaceAfter=3),
    "small": ParagraphStyle("s", fontName="DV", fontSize=7.2, leading=9.2, textColor=colors.HexColor(INK2)),
    "cell": ParagraphStyle("c", fontName="DV", fontSize=7.1, leading=8.8),
}
P = lambda t, s="p": Paragraph(t, st[s])  # noqa: E731


def table(rows, widths):
    data = [[P(c, "cell") for c in row] for row in rows]
    t = Table(data, colWidths=[w * mm for w in widths])
    t.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, 0), "DV-B"), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef3fa")),
        ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor(GRID)), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]))
    return t


def fig(path, h=52):
    return Image(str(path), width=180 * mm, height=h * mm, kind="proportional")


f = facts
ok = "<font color='#0a7a0a'>✓</font>"
story = [
    P("Partition Playground — scripted adversaries on the Lab 03 network", "h1"),
    P("A scenario-driven laboratory around Lab 03's <i>consensus</i> package. The engine subclasses Lab 03's "
      "<font face='DVM'>Network</font>/<font face='DVM'>Node</font> (gossip, heaviest-chain fork choice, "
      "<font face='DVM'>getchain</font> reconciliation, exponential-race mining are inherited unchanged) and runs one "
      "Lab 03 <font face='DVM'>pos.BeaconState</font> per node as the Casper FFG gadget, voting over the same gossip "
      "network. Lab 03's asyncio code runs on a <b>virtual-clock event loop</b>, so every scenario is deterministic from its "
      "seed (byte-identical event streams across processes and <font face='DVM'>PYTHONHASHSEED</font>s) and the full "
      "test suite runs in ≈ 21 s. Scenarios are YAML (network, adversaries, timeline, <i>expect</i>); the engine emits a JSON "
      "event stream that feeds metrics, tests and the dashboard. Settings unless stated: 10 honest nodes, 3 peers each, "
      "mean block time T = 10 s, one-hop latency 0.5 s (jitter U(0.5, 1.5)), 10 validators × 32 ETH, 40 s epochs."),
    table([["Scenario", "Expected (asserted in tests)", "Observed", ""],
           ["50/50 partition + heal", "both sides keep mining; reorg ≥ 5 on heal; converge ≤ 120 s; no finality during split; no conflicting finality",
            f"reorg {f['p50']['reorg']}, converged after {f['p50']['conv']:.0f} s; finality frozen at epoch {f['p50']['fin_frozen']}; 0 conflicts", ok],
           ["70/30 partition", "majority reorg ≤ 2, minority ≥ 5; majority finalises every epoch; minority frozen",
            f"majority {f['p70']['major_reorg']}, minority {f['p70']['minor_reorg']}; finalised epoch at heal: 70 % side {f['p70']['major_fin_heal']}, 30 % side {f['p70']['minor_fin_heal']}", ok],
           ["Eclipse of node9", "payment ≥ 6 confs then 0 (double spend); victim reorg ≥ 6; victim finality lag +1/epoch",
            f"peak {f['ecl']['pay_max']} confs → {f['ecl']['pay_end']}; reorg {f['ecl']['reorg']}; lag up to {f['ecl']['lag_max']} epochs", ok],
           ["High latency (sweep)", "stale rate strictly increasing in Δ/T, within 0.6–1.1 × analytic",
            " → ".join(f"{100 * p[1]:.1f}%" for p in f["orph"]["sweep"]), ok],
           ["Orphan rate, Δ = 0.1 T", f"stale rate in documented band [{100 * f['orph']['band'][0]:.1f} %, {100 * f['orph']['band'][1]:.1f} %] around 9.52 %",
            f"{100 * f['orph']['rate']:.2f} % ± {100 * f['orph']['se']:.2f} (n = {f['orph']['n']})", ok],
           ["FFG, 40 % stake offline", f"leak starts epoch {f['ffg']['pred']['leak_starts']}; justified again {f['ffg']['pred']['justified_again']}; finalised again {f['ffg']['pred']['finalized_again']} (bare Lab 03 BeaconState prediction)",
            f"leak {f['ffg']['leak']}, justified {f['ffg']['obs_j']}, finalised {f['ffg']['obs_f']}; lag peaked at {f['ffg']['lag_max']}", ok],
           ["Extras", "delayed relay raises stale rate ≥ 3 pp; equivocation evidence at all nodes ≤ 10 s; long partition → conflicting finality",
            f"{100 * f['relay']['without']:.1f} % → {100 * f['relay']['with']:.1f} %; evidence at {f['eq']['n']} nodes within {f['eq']['last']:.1f} s; {f['long']['conflicts']} conflicting epochs", ok]],
          [30, 66, 76, 6]),
]

story += [KeepTogether([P("1 · 50/50 partition and heal", "h2"), fig(fig_p50)]),
          P(f"<b>Expected vs observed.</b> During the 400 s split both halves kept producing blocks (side A {f['p50']['h0']}→{f['p50']['hA']}, "
            f"side B {f['p50']['h0']}→{f['p50']['hB']}): {f['p50']['dropped']} messages were silently dropped. At the heal Lab 03 nodes announced their heads and pulled "
            f"the peer's chain (<font face='DVM'>getchain</font>); the lighter half adopted the heavier branch and un-confirmed {f['p50']['reorg']} blocks, and all "
            f"tips agreed {f['p50']['conv']:.1f} s after the heal (with equal heights the tie would persist until the next block). "
            f"FFG: neither half holds > 2/3 of the stake, so no checkpoint was justified — finality stayed at epoch {f['p50']['fin_frozen']} on both sides, then resumed "
            f"(epoch {f['p50']['fin_end']} at the end)."),
          P("<b>CAP / safety–liveness.</b> A partition forces the choice. Nakamoto PoW picks <i>availability</i>: each side accepts transactions and "
            "confirms them, and consistency is restored only by discarding one side's history — its confirmations were never safe. FFG picks "
            "<i>consistency</i>: with no 2/3 quorum reachable it stops finalising (loses liveness) rather than finalise two histories. FLP is visible too: "
            "a partitioned node cannot tell a dead peer from a slow one, so no deterministic protocol can both always decide and never decide wrongly.")]

story += [KeepTogether([P("2 · 70/30 partition", "h2"), fig(fig_p70)]),
          P(f"<b>Expected vs observed.</b> The 70 % side kept the supermajority of stake, so it finalised every epoch throughout (epoch {f['p70']['major_fin_heal']} at heal) and its "
            f"chain only saw ordinary forks (max reorg {f['p70']['major_reorg']}). The 30 % side kept mining at 30 % of the rate — its private branch grew to "
            f"{f['p70']['minor_branch']} blocks (left) — but its finality froze at "
            f"epoch {f['p70']['minor_fin_heal']}; at the heal it lost its whole {f['p70']['minor_reorg']}-block branch and adopted the majority's justification proofs "
            "(verified against its own balances), catching up on finality within one epoch."),
          P("<b>Interpretation.</b> Safety and liveness both survive on the side that holds > 2/3 of the stake; the minority keeps <i>availability without "
            "finality</i>. An operator on the minority side sees exactly the signal that matters: the PoW chain advances, the finalised checkpoint does not.")]

story += [KeepTogether([P("3 · Eclipse of one node", "h2"), fig(fig_ecl)]),
          P(f"<b>Expected vs observed.</b> Two attacker nodes (17 % of hash power together) took all of node9's connection slots for 600 s and fed it a private chain. "
            f"A payment to node9 reached {f['ecl']['pay_max']} confirmations on that chain while the honest chain confirmed a conflicting spend of the same coins; when "
            f"the eclipse ended node9 reorganised {f['ecl']['reorg']} blocks and the payment fell to {f['ecl']['pay_end']} confirmations — a successful double spend "
            f"against a node that followed the '6 confirmations' rule. Its FFG view saw no votes, so its finality lag grew by one per epoch (to {f['ecl']['lag_max']}); "
            f"afterwards it adopted the honest proofs and jumped to epoch {f['ecl']['fin_after']}."),
          P("<b>Interpretation.</b> An eclipse is a <i>targeted partition</i>: the synchrony assumption behind PoW security (honest blocks reach you within Δ) is "
            "violated for one node only, so heaviest-chain is evaluated over an adversarial subset and k confirmations certify nothing. FFG stays <i>safe</i> for the "
            "victim — the attackers have no stake, so it never finalises their chain — but loses liveness, which makes finality lag a cheap, high-signal eclipse alarm "
            "(the dashboard raises it when one node is alone on a branch and ≥ 4 epochs behind).")]

story += [KeepTogether([P("4 · Latency and the orphan rate", "h2"), fig(fig_lat, 56)]),
          P(f"<b>Expected vs observed.</b> On a full mesh (one hop) with ten equal miners the stale rate rises monotonically with Δ/T "
            f"({', '.join(f'{100 * p[1]:.1f} %' for p in f['orph']['sweep'])} for Δ/T = 0.02…0.4). Calibration at Δ = 0.1 T: measured "
            f"{100 * f['orph']['rate']:.2f} % ± {100 * f['orph']['se']:.2f} pp over {f['orph']['n']} blocks. The documented band is the analytic 9.52 % ± 2.5 pp, budgeted as "
            f"a −1.0 pp systematic term (a miner never races its own block: 1 − E[e^(−0.9Δ/T)] = {100 * f['orph']['refined']:.2f} %) plus ±3σ sampling noise; the measurement "
            f"is within 3σ of the refined estimate as well. At large Δ/T the simple formula overestimates, because chains of forks resolve together. "
            f"A relay that holds others' blocks for 4 s on the only bridge between two clusters lifted the stale rate from {100 * f['relay']['without']:.1f} % to "
            f"{100 * f['relay']['with']:.1f} %."),
          P("<b>Interpretation.</b> Under partial synchrony, Δ/T is the security parameter of Nakamoto consensus: stale blocks are wasted honest work, so the "
            "fraction of hash power needed to out-race the network falls below 50 % as Δ/T grows, and a well-connected miner (or a delaying relay) gains an edge "
            "— the selfish-relay effect.")]

story += [KeepTogether([P("5 · Casper FFG with 40 % of the stake offline", "h2"), fig(fig_ffg, 50)]),
          P(f"<b>Expected vs observed.</b> Four of ten validators stopped attesting after epoch 9. 60 % < 2/3, so nothing was justified and the finality lag grew by "
            f"exactly one per epoch (to {f['ffg']['lag_max']}) while PoW blocks kept coming (height {f['ffg']['h10']} at epoch 10 → {f['ffg']['h33']} at epoch 33). Lab 03's "
            f"inactivity leak engaged once more than 4 epochs had passed since the last finalisation (epoch {f['ffg']['leak']}) and drained each absent validator by 1/64 "
            f"per epoch; when the online share crossed 2/3 the link 9 → {f['ffg']['obs_j']} justified, and epoch {f['ffg']['obs_f']} finalised its predecessor. These "
            "epochs are asserted and equal those of a bare Lab 03 BeaconState with no network, so gossip added no error."),
          P("<b>Interpretation.</b> FFG is safety-first: it refuses to finalise without a 2/3 quorum. The leak is the liveness escape hatch — it redefines the "
            "quorum by shrinking absent stake. In this outage that is benign. Run under a <i>partition</i> instead, each side leaks the other: in a 55-epoch 50/50 split "
            f"both halves eventually finalised different checkpoints ({f['long']['conflicts']} conflicting epochs; nodes {', '.join(f['long']['reverted_nodes'])} later saw their "
            "finalised checkpoints reverted by the PoW reorg on heal). Liveness under long partitions is bought with safety — CAP applies to finality gadgets too."),
          P("<b>Stretch: equivocation.</b> node3 sent conflicting attestations for epoch 5 to different halves of its peers. The double-vote evidence travelled through "
            f"gossip and reached all {f['eq']['n']} other honest nodes between {f['eq']['first']:.2f} s and {f['eq']['last']:.2f} s after the act; every view applied Lab 03's "
            "slashing (1/32 + correlated penalty) and finality continued on the remaining 90 %."),
          P("<b>Limitations.</b> Hash power and stake are co-located per node; checkpoint choice uses a fixed age margin rather than LMD-GHOST; Lab 03's PoW fork choice "
            "is finality-unaware, so reverted finality is measured, not prevented; latency is i.i.d. per message.", "small")]

doc = SimpleDocTemplate(str(OUT), pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=13 * mm,
                        bottomMargin=12 * mm, title="Partition Playground report")
doc.build(story)
print(OUT)
for k, v in facts.items():
    print(k, v)
