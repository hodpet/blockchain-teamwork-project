/* Partition Playground dashboard - replays (or streams) the engine's JSON event stream.
   No dependencies. Every derived number is recomputed from the events, the same way
   playground/metrics.py does it. */
"use strict";

const $ = (s) => document.querySelector(s);
const SVGNS = "http://www.w3.org/2000/svg";
const CONFIRM_DEPTH = 6; // a block this deep under the main tip counts for the orphan rate

// ------------------------------------------------------------------ state
let EVENTS = [];
let INFO = null;
let cursor = 0;
let tNow = 0;
let playing = false;
let speed = 20;
let S = null; // derived state

function freshState() {
  const nodes = {};
  for (const [id, n] of Object.entries(INFO.nodes)) {
    nodes[id] = { id, role: n.role, peers: [...n.peers], tip: INFO.genesis, height: 0,
                  justified: 0, finalized: 0, leaking: false };
  }
  return {
    nodes, origPeers: null,
    blocks: new Map([[INFO.genesis, { parent: null, height: 0, miner: "genesis", t: 0 }]]),
    mined: [],
    partition: null, eclipse: null, offline: new Set(), relayDelay: {},
    reorgs: [], actions: [], log: [],
    ffg: {}, // node -> [{epoch, lag, leaking}]
    epoch: 0, dropped: 0, slashed: new Set(), evidence: [],
    series: { div2: [], div3: [], orphan: [] },
    lastSnapshot: null,
  };
}

function natural(a, b) {
  const ra = a.match(/^(\D*)(\d*)$/), rb = b.match(/^(\D*)(\d*)$/);
  return ra[1] === rb[1] ? (+ra[2] || 0) - (+rb[2] || 0) : ra[1].localeCompare(rb[1]);
}
const nodeIds = () => Object.keys(S.nodes).sort(natural);

// ------------------------------------------------------------------ chain helpers
function ancestorAtHeight(hash, h) {
  let b = S.blocks.get(hash), cur = hash;
  while (b && b.height > h) { cur = b.parent; b = S.blocks.get(cur); }
  return cur;
}
function commonAncestorHeight(a, b) {
  let ba = S.blocks.get(a), bb = S.blocks.get(b);
  if (!ba || !bb) return 0;
  let ha = a, hb = b;
  while (ba.height > bb.height) { ha = ba.parent; ba = S.blocks.get(ha); }
  while (bb.height > ba.height) { hb = bb.parent; bb = S.blocks.get(hb); }
  while (ha !== hb && ba && bb) { ha = ba.parent; hb = bb.parent; ba = S.blocks.get(ha); bb = S.blocks.get(hb); }
  return ba ? ba.height : 0;
}

/** Branches group tips by ANCESTRY: a node that is merely a block behind (or ahead) on the same
 *  chain is on the same branch. Branches are ranked by how many honest nodes are on them:
 *  rank 0 = main branch (slot 1), rank 1 = slot 2, everything else folds into slot 3. */
function branches() {
  const tips = [...new Set(nodeIds().map((id) => S.nodes[id].tip))]
    .sort((a, b) => S.blocks.get(b).height - S.blocks.get(a).height || a.localeCompare(b));
  const heads = []; // branch heads (highest tip of each branch)
  const branchOf = new Map();
  for (const t of tips) {
    const h = S.blocks.get(t).height;
    const head = heads.find((hd) => ancestorAtHeight(hd, h) === t);
    if (head) branchOf.set(t, head); else { heads.push(t); branchOf.set(t, t); }
  }
  const honestCount = new Map(heads.map((h) => [h, 0]));
  for (const id of nodeIds()) if (S.nodes[id].role === "honest") {
    const hd = branchOf.get(S.nodes[id].tip); honestCount.set(hd, honestCount.get(hd) + 1);
  }
  heads.sort((a, b) => honestCount.get(b) - honestCount.get(a) || S.blocks.get(b).height - S.blocks.get(a).height || a.localeCompare(b));
  const headRank = new Map(heads.map((h, i) => [h, Math.min(i, 2)]));
  const rank = new Map(tips.map((t) => [t, headRank.get(branchOf.get(t))]));
  const count = new Map(tips.map((t) => [t, honestCount.get(branchOf.get(t))]));
  return { main: heads[0], heads, rank, tips, count, branchOf, honestCount };
}
const BRANCH_NAMES = ["Main branch", "Branch 2", "Other branches"];
const slotVar = (i) => `var(--series-${i + 1})`;

// ------------------------------------------------------------------ applying events
function apply(e) {
  switch (e.type) {
    case "mined":
      S.blocks.set(e.hash, { parent: e.parent, height: e.height, miner: e.node, t: e.t });
      S.mined.push(e);
      break;
    case "tip": {
      const n = S.nodes[e.node];
      n.tip = e.hash; n.height = e.height;
      if (e.depth > 0) {
        S.reorgs.push(e);
        if (e.depth >= 3) logLine(e.t, `${e.node} reorganised ${e.depth} blocks deep`);
      }
      break;
    }
    case "action": handleAction(e); break;
    case "snapshot": onSnapshot(e); break;
    case "ffg": {
      const n = S.nodes[e.node];
      n.justified = e.justified; n.finalized = e.finalized; n.leaking = e.leaking;
      (S.ffg[e.node] ||= []).push({ epoch: e.epoch, lag: e.epoch - e.finalized, leaking: e.leaking,
                                    active: e.active, voting: e.voting });
      S.epoch = Math.max(S.epoch, e.epoch);
      if (e.slashed && e.slashed.length) for (const v of e.slashed) S.slashed.add(v);
      break;
    }
    case "slashing_evidence":
      S.evidence.push(e);
      logLine(e.t, `${e.node} holds ${e.rule.replace("_", " ")} evidence against ${e.validator}`);
      break;
    case "ffg_sync":
      if (INFO.nodes[e.node]?.role !== "honest") break;
      logLine(e.t, `${e.node} adopted justification proofs from ${e.sender} → finalized ${e.finalized}`);
      break;
    case "end":
      S.dropped = e.dropped;
      logLine(e.t, "end of scenario");
      break;
  }
}

function handleAction(e) {
  S.actions.push(e);
  const k = e.kind;
  if (k === "partition") {
    S.partition = e.groups;
    logLine(e.t, `PARTITION ${e.groups.map((g) => g.length).join(" / ")}: ${e.groups.map((g) => g.join(",")).join(" | ")}`);
  } else if (k === "heal") {
    S.partition = null; logLine(e.t, "partition healed");
  } else if (k === "eclipse") {
    S.origPeers = Object.fromEntries(nodeIds().map((id) => [id, [...S.nodes[id].peers]]));
    for (const id of nodeIds()) {
      if (id !== e.victim && !e.attackers.includes(id)) S.nodes[id].peers = S.nodes[id].peers.filter((p) => p !== e.victim);
    }
    S.nodes[e.victim].peers = [...e.attackers];
    for (const a of e.attackers) if (!S.nodes[a].peers.includes(e.victim)) S.nodes[a].peers.push(e.victim);
    S.eclipse = { victim: e.victim, attackers: e.attackers };
    logLine(e.t, `ECLIPSE: ${e.attackers.join(", ")} occupy every connection of ${e.victim}`);
  } else if (k === "end_eclipse") {
    if (S.origPeers) for (const [id, p] of Object.entries(S.origPeers)) S.nodes[id].peers = p;
    S.eclipse = null; logLine(e.t, "eclipse ended — victim reconnects to honest peers");
  } else if (k === "offline") {
    e.validators.forEach((v) => S.offline.add(v));
    logLine(e.t, `validators offline: ${e.validators.join(", ")}`);
  } else if (k === "online") {
    e.validators.forEach((v) => S.offline.delete(v));
    logLine(e.t, `validators back online: ${e.validators.join(", ")}`);
  } else if (k === "relay_delay") {
    S.relayDelay[e.node] = e.delay; logLine(e.t, `${e.node} now delays relayed blocks by ${e.delay} s`);
  } else if (k === "latency") {
    logLine(e.t, `base latency → ${e.latency} s`);
  } else if (k === "tx") {
    logLine(e.t, `transaction ${e.label} submitted to ${e.node}`);
  } else if (k === "equivocate") {
    logLine(e.t, `${e.validator} EQUIVOCATES in epoch ${e.epoch} (two conflicting votes)`);
  }
}

function onSnapshot(e) {
  S.lastSnapshot = e;
  const br = branches();
  // divergence: blocks on branch r since its fork from the main branch
  const best = [0, 0, 0];
  for (const head of br.heads) {
    const r = br.rank.get(head);
    if (r === 0) continue;
    const d = S.blocks.get(head).height - commonAncestorHeight(head, br.main);
    best[r] = Math.max(best[r], d);
  }
  S.netDropped = e.dropped; S.netDelivered = e.delivered;
  S.series.div2.push([e.t, best[1]]);
  S.series.div3.push([e.t, best[2]]);
  // orphan rate so far: blocks >= CONFIRM_DEPTH under the main tip, off the main chain
  const mainH = S.blocks.get(br.main).height;
  const onMain = new Set();
  let h = br.main;
  while (h) { onMain.add(h); const b = S.blocks.get(h); h = b ? b.parent : null; }
  let n = 0, stale = 0;
  for (const m of S.mined) {
    if (m.height > mainH - CONFIRM_DEPTH) continue;
    n++; if (!onMain.has(m.hash)) stale++;
  }
  if (n >= 10) S.series.orphan.push([e.t, stale / n]);
  S.orphanNow = n ? { rate: stale / n, n, stale } : null;
}

const MAX_LOG = 400;
function logLine(t, text) { S.log.push({ t, text }); if (S.log.length > MAX_LOG) S.log.shift(); }

function seek(t) {
  if (t < tNow || !S) { S = freshState(); cursor = 0; }
  while (cursor < EVENTS.length && EVENTS[cursor].t <= t) apply(EVENTS[cursor++]);
  tNow = t;
}

// ------------------------------------------------------------------ rendering: shared
const tooltip = $("#tooltip");
function showTip(evt, head, rows) {
  tooltip.replaceChildren();
  const h = document.createElement("div"); h.className = "tt-head"; h.textContent = head; tooltip.append(h);
  for (const r of rows) {
    const row = document.createElement("div"); row.className = "tt-row";
    if (r.color) { const ln = document.createElement("span"); ln.className = "ln"; ln.style.background = r.color; row.append(ln); }
    const v = document.createElement("strong"); v.textContent = r.value; row.append(v);
    if (r.name) { const nm = document.createElement("span"); nm.className = "name"; nm.textContent = r.name; row.append(nm); }
    tooltip.append(row);
  }
  tooltip.hidden = false;
  const x = Math.min(evt.clientX + 14, window.innerWidth - tooltip.offsetWidth - 8);
  const y = Math.min(evt.clientY + 14, window.innerHeight - tooltip.offsetHeight - 8);
  tooltip.style.left = `${x}px`; tooltip.style.top = `${y}px`;
}
function hideTip() { tooltip.hidden = true; }

function el(tag, attrs = {}, parent) {
  const n = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
  if (parent) parent.append(n);
  return n;
}
function text(parent, x, y, str, cls, extra = {}) {
  const t = el("text", { x, y, class: cls, ...extra }, parent); t.textContent = str; return t;
}
const fmtT = (t) => (t >= 3600 ? `${(t / 3600).toFixed(1)} h` : t >= 120 ? `${Math.round(t / 60)} min` : `${Math.round(t)} s`);
/** Axis maximum whose quarter-steps are round numbers (ticks at 0, ¼, ½, ¾, 1). */
function niceMax(v) {
  if (v <= 0) return 1;
  const p = 10 ** Math.floor(Math.log10(v)), m = v / p;
  return (m <= 1.2 ? 1.2 : m <= 2 ? 2 : m <= 4 ? 4 : m <= 8 ? 8 : 12) * p;
}

/** Time-axis frame: gridlines, ticks, scenario action markers and the "now" line. */
function frame(svg, W, H, M, yMax, yFmt) {
  svg.replaceChildren();
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  const x = (t) => M.l + (t / INFO.duration) * (W - M.l - M.r);
  const y = (v) => H - M.b - (v / yMax) * (H - M.t - M.b);
  for (let i = 0; i <= 4; i++) {
    const v = (yMax * i) / 4;
    el("line", { x1: M.l, x2: W - M.r, y1: y(v), y2: y(v), class: i ? "gridline" : "axis" }, svg);
    text(svg, M.l - 6, y(v) + 3.5, yFmt(v), "tick", { "text-anchor": "end" });
  }
  for (let i = 0; i <= 4; i++) {
    const t = (INFO.duration * i) / 4;
    text(svg, x(t), H - M.b + 14, fmtT(t), "tick", { "text-anchor": i === 0 ? "start" : i === 4 ? "end" : "middle" });
  }
  let lastX = -1e9;
  for (const a of EVENTS_ACTIONS) {
    const ax = x(a.t);
    el("line", { x1: ax, x2: ax, y1: M.t, y2: H - M.b, class: "marker-line" }, svg);
    if (ax - lastX > 56) { text(svg, ax + 3, M.t + 8, a.kind.replace("_", " "), "marker-label"); lastX = ax; }
  }
  el("line", { x1: x(tNow), x2: x(tNow), y1: M.t, y2: H - M.b, class: "now" }, svg);
  return { x, y };
}
let EVENTS_ACTIONS = [];

function lineChart(container, { series, yMax, yFmt, refs = [], tipFmt }) {
  const W = 620, H = 210, M = { l: 40, r: 74, t: 14, b: 22 };
  let svg = container.querySelector("svg");
  if (!svg) { svg = el("svg", { role: "img" }); container.append(svg); }
  const { x, y } = frame(svg, W, H, M, yMax, yFmt);
  for (const r of refs) {
    const pts = r.points.map(([t, v]) => `${x(t)},${y(Math.min(v, yMax))}`).join(" ");
    el("polyline", { points: pts, class: "ref", fill: "none" }, svg);
    const first = r.points[0];
    if (first) text(svg, x(first[0]) + 6, y(Math.min(first[1], yMax)) - 5, r.label, "ref-label");
  }
  for (const s of series) {
    if (!s.points.length) continue;
    el("polyline", { points: s.points.map(([t, v]) => `${x(t)},${y(v)}`).join(" "), class: "series", stroke: s.color }, svg);
    const [lt, lv] = s.points[s.points.length - 1];
    el("circle", { cx: x(lt), cy: y(lv), r: 4, fill: s.color, stroke: "var(--surface-1)", "stroke-width": 2 }, svg);
    if (s.label) text(svg, x(lt) + 8, y(lv) + 4, s.label(lv), "end-label");
  }
  // crosshair layer
  const hit = el("rect", { x: M.l, y: M.t, width: W - M.l - M.r, height: H - M.t - M.b, fill: "transparent" }, svg);
  const cross = el("line", { y1: M.t, y2: H - M.b, class: "crosshair", visibility: "hidden" }, svg);
  hit.addEventListener("pointermove", (evt) => {
    const box = svg.getBoundingClientRect();
    const px = ((evt.clientX - box.left) / box.width) * W;
    const t = ((px - M.l) / (W - M.l - M.r)) * INFO.duration;
    const rows = [];
    let snapT = null;
    for (const s of series) {
      if (!s.points.length) continue;
      let best = s.points[0];
      for (const p of s.points) if (Math.abs(p[0] - t) < Math.abs(best[0] - t)) best = p;
      snapT = best[0];
      rows.push({ color: s.color, value: tipFmt(best[1]), name: s.name });
    }
    if (snapT === null) return;
    cross.setAttribute("x1", x(snapT)); cross.setAttribute("x2", x(snapT)); cross.setAttribute("visibility", "visible");
    showTip(evt, `t = ${Math.round(snapT)} s`, rows);
  });
  hit.addEventListener("pointerleave", () => { cross.setAttribute("visibility", "hidden"); hideTip(); });
}

// ------------------------------------------------------------------ rendering: panels
function renderKPIs(br) {
  const nb = br.heads.length, nt = br.tips.length;
  setTile("#kpi-tips", `${nb}`, nb > 1 ? statusNote("warning", "!", `competing branches · ${nt} distinct tips`)
    : statusNote("good", "✓", nt > 1 ? `one branch · ${nt} tips (propagating)` : "all nodes agree"));
  const maxR = S.reorgs.reduce((m, r) => Math.max(m, r.depth), 0);
  const deep = S.reorgs.filter((r) => r.depth >= 3).length;
  setTile("#kpi-reorg", String(maxR), maxR >= 6 ? statusNote("critical", "!", `${deep} deep reorgs`) : maxR >= 3 ? statusNote("warning", "!", `${deep} reorgs ≥ 3`) : plainNote(`${S.reorgs.length} reorg${S.reorgs.length === 1 ? "" : "s"} total`));
  const o = S.orphanNow;
  const ref = 1 - Math.exp(-INFO.latency / INFO.block_time);
  setTile("#kpi-orphan", o ? `${(o.rate * 100).toFixed(1)}%` : "–", plainNote(`analytic ${(ref * 100).toFixed(1)}% at Δ/T = ${(INFO.latency / INFO.block_time).toFixed(2)}`));
  if (INFO.ffg) {
    let worst = 0, who = "";
    for (const id of nodeIds()) {
      const s = S.ffg[id]; if (!s || !s.length) continue;
      const l = s[s.length - 1].lag; if (l > worst) { worst = l; who = id; }
    }
    const allLag = nodeIds().filter((id) => S.ffg[id]?.length && S.ffg[id][S.ffg[id].length - 1].lag === worst).length;
    const note = worst >= 5 ? statusNote("critical", "!", allLag > 1 && allLag >= nodeIds().filter((i) => S.ffg[i]).length - 1 ? "finality stalled network-wide" : `${who} not finalising`)
      : worst >= 3 ? statusNote("warning", "!", `${who} behind`) : statusNote("good", "✓", "finalising every epoch");
    setTile("#kpi-final", `${worst} ep`, note);
  } else setTile("#kpi-final", "n/a", plainNote("no FFG in this scenario"));
  const dropped = S.netDropped ?? 0;
  const share = S.netDelivered ? (100 * dropped) / (dropped + S.netDelivered) : 0;
  setTile("#kpi-net", dropped.toLocaleString("en"), plainNote(`${share.toFixed(1)}% of sent · ${S.partition ? "partitioned now" : S.eclipse ? "eclipse active" : "connected"}`));
}
function setTile(sel, value, noteNode) {
  const t = $(sel);
  t.querySelector(".tile-value").textContent = value;
  t.querySelector(".tile-note").replaceChildren(noteNode);
}
function statusNote(kind, icon, label) {
  const s = document.createElement("span"); s.style.display = "inline-flex"; s.style.gap = "6px"; s.style.alignItems = "center";
  const d = document.createElement("span"); d.className = "status-dot"; d.style.background = `var(--${kind})`;
  d.setAttribute("aria-hidden", "true");
  const tx = document.createElement("span"); tx.textContent = `${icon} ${label}`;
  s.append(d, tx); return s;
}
function plainNote(label) { const s = document.createElement("span"); s.textContent = label; return s; }

function renderAlarms(br) {
  const box = $("#alarms"); box.replaceChildren();
  const add = (kind, icon, label) => {
    const a = document.createElement("div"); a.className = `alarm ${kind}`;
    const i = document.createElement("span"); i.className = "icon"; i.textContent = icon;
    const l = document.createElement("span"); l.textContent = label;
    a.append(i, l); box.append(a);
  };
  if (S.partition) add("critical", "!", `Network partitioned ${S.partition.map((g) => g.length).join(" / ")}`);
  if (S.eclipse) add("critical", "!", `${S.eclipse.victim}: all ${S.nodes[S.eclipse.victim].peers.length} peers are attacker nodes`);
  // operator heuristic: one node alone on a branch AND not finalising
  for (const id of nodeIds()) {
    const n = S.nodes[id];
    if (n.role !== "honest") continue;
    const lag = S.ffg[id]?.length ? S.ffg[id][S.ffg[id].length - 1].lag : 0;
    const alone = br.rank.get(n.tip) > 0 && br.honestCount.get(br.branchOf.get(n.tip)) <= 1;
    if (alone && lag >= 4) add("warning", "?", `${id} is alone on a branch and ${lag} epochs behind on finality — possible eclipse`);
  }
  if (S.offline.size) add("warning", "!", `${S.offline.size} validators offline (${Math.round((100 * S.offline.size) / Object.values(INFO.nodes).filter((n) => n.role === "honest").length)}% of stake)`);
  const leaking = nodeIds().some((id) => S.nodes[id].leaking);
  if (leaking) add("warning", "▲", "Inactivity leak active: absent validators are being drained");
  if (S.slashed.size) add("critical", "✕", `Slashed: ${[...S.slashed].join(", ")}`);
  if (S.relayDelay && Object.keys(S.relayDelay).length) add("warning", "!", `Delayed relay at ${Object.keys(S.relayDelay).join(", ")}`);
}

function layout() {
  const ids = nodeIds();
  const W = 640, H = 380, pos = {};
  const honest = ids.filter((id) => S.nodes[id].role === "honest");
  const attackers = ids.filter((id) => S.nodes[id].role !== "honest");
  const ring = (list, cx, cy, rx, ry, start = -Math.PI / 2) => list.forEach((id, i) => {
    const a = start + (2 * Math.PI * i) / Math.max(list.length, 1);
    pos[id] = [cx + rx * Math.cos(a), cy + ry * Math.sin(a)];
  });
  const groups = [];
  if (S.partition) {
    const n = S.partition.length;
    S.partition.forEach((g, i) => {
      const cx = (W * (i + 0.5)) / n, cy = H / 2 - 6;
      ring(g, cx, cy, Math.min(120, W / n / 2 - 30), 120);
      groups.push({ cx, cy, rx: Math.min(150, W / n / 2 - 8), ry: 160, label: `side ${String.fromCharCode(65 + i)} · ${g.length} nodes` });
    });
  } else if (S.eclipse) {
    const rest = honest.filter((id) => id !== S.eclipse.victim);
    ring(rest, 230, H / 2 - 4, 170, 140);
    pos[S.eclipse.victim] = [545, H / 2 - 4];
    S.eclipse.attackers.forEach((a, i) => { pos[a] = [470, 95 + i * (H - 190) / Math.max(1, S.eclipse.attackers.length - 1)]; });
    groups.push({ cx: 515, cy: H / 2 - 4, rx: 100, ry: 165, label: "eclipsed" });
  } else {
    ring(honest, W / 2 - (attackers.length ? 60 : 0), H / 2 - 4, 200, 150);
    attackers.forEach((a, i) => { pos[a] = [560, 110 + i * 80]; });
  }
  return { pos, groups, W, H };
}

function renderGraph(br) {
  const svg = $("#graph");
  const { pos, groups } = layout();
  if (!svg._layers) {
    svg._layers = { hulls: el("g", {}, svg), edges: el("g", {}, svg), nodes: el("g", {}, svg) };
    svg._nodes = {};
  }
  const { hulls, edges, nodes } = svg._layers;
  hulls.replaceChildren();
  for (const g of groups) {
    el("ellipse", { cx: g.cx, cy: g.cy, rx: g.rx, ry: g.ry, class: "hull" }, hulls);
    text(hulls, g.cx, g.cy - g.ry + 16, g.label, "group-label");
  }
  edges.replaceChildren();
  const seen = new Set();
  const groupOf = {};
  if (S.partition) S.partition.forEach((g, i) => g.forEach((id) => { groupOf[id] = i; }));
  for (const id of nodeIds()) {
    for (const p of S.nodes[id].peers) {
      const key = [id, p].sort().join("|");
      if (seen.has(key) || !pos[id] || !pos[p]) continue;
      seen.add(key);
      const cut = S.partition && groupOf[id] !== groupOf[p];
      const attack = S.eclipse && (S.eclipse.attackers.includes(id) || S.eclipse.attackers.includes(p)) &&
        (id === S.eclipse.victim || p === S.eclipse.victim);
      el("line", { x1: pos[id][0], y1: pos[id][1], x2: pos[p][0], y2: pos[p][1],
                   class: `edge${cut ? " cut" : ""}${attack ? " attack" : ""}` }, edges);
    }
  }
  for (const id of nodeIds()) {
    let g = svg._nodes[id];
    if (!g) {
      g = el("g", { class: "node", tabindex: 0 }, nodes);
      g._ring = el("circle", { r: 20, class: "ring", visibility: "hidden" }, g);
      g._body = el("circle", { r: 14, class: "body" }, g);
      g._id = text(g, 0, 31, id, "id");
      g._h = text(g, 0, 43, "", "");
      g.addEventListener("pointermove", (evt) => {
        const n = S.nodes[id], b = branches();
        showTip(evt, id, [
          { color: slotVar(b.rank.get(n.tip)), value: BRANCH_NAMES[b.rank.get(n.tip)], name: `tip ${n.tip}` },
          { value: String(n.height), name: "height" },
          { value: `${n.peers.length}`, name: `peers: ${n.peers.join(", ")}` },
          ...(INFO.ffg && n.role === "honest" ? [{ value: `ep ${n.finalized}`, name: "finalized" }] : []),
        ]);
      });
      g.addEventListener("pointerleave", hideTip);
      svg._nodes[id] = g;
    }
    const n = S.nodes[id];
    const [x, y] = pos[id] || [0, 0];
    g.setAttribute("transform", `translate(${x.toFixed(1)},${y.toFixed(1)})`);
    g.style.transform = `translate(${x.toFixed(1)}px,${y.toFixed(1)}px)`;
    g._body.style.fill = slotVar(br.rank.get(n.tip));
    g._body.setAttribute("r", n.role === "honest" ? 14 : 11);
    g._ring.setAttribute("visibility", S.eclipse && S.eclipse.victim === id ? "visible" : "hidden");
    g._id.textContent = n.role === "honest" ? id : `${id} ⚔`;
    g._h.textContent = `h ${n.height}${S.offline.has(id) ? " · offline" : ""}`;
  }
  // legend
  const lg = $("#branch-legend"); lg.replaceChildren();
  const ranksPresent = [...new Set([...br.rank.values()])].sort();
  for (const r of ranksPresent) {
    const k = document.createElement("span"); k.className = "key";
    const sw = document.createElement("span"); sw.className = "sw"; sw.style.background = slotVar(r);
    const nodesOn = nodeIds().filter((id) => br.rank.get(S.nodes[id].tip) === r).length;
    const l = document.createElement("span");
    l.textContent = `${BRANCH_NAMES[r]} · ${nodesOn} node${nodesOn === 1 ? "" : "s"}${r === 0 ? ` · head ${br.main}` : ""}`;
    k.append(sw, l); lg.append(k);
  }
  if (S.eclipse) {
    const k = document.createElement("span"); k.className = "key";
    const ln = document.createElement("span"); ln.className = "ln"; ln.style.background = "var(--series-3)";
    const l = document.createElement("span"); l.textContent = "attacker link";
    k.append(ln, l); lg.append(k);
  }
}

function renderTable(br) {
  const tb = $("#node-table tbody"); tb.replaceChildren();
  for (const id of nodeIds()) {
    const n = S.nodes[id];
    const tr = document.createElement("tr");
    const r = br.rank.get(n.tip);
    const cells = [
      id, n.role + (S.offline.has(id) ? " (offline)" : ""), String(n.height), n.tip, null,
      INFO.ffg && n.role === "honest" ? String(n.finalized) : "–",
      INFO.ffg && n.role === "honest" && S.ffg[id]?.length ? String(S.ffg[id][S.ffg[id].length - 1].lag) : "–",
    ];
    cells.forEach((c, i) => {
      const td = document.createElement("td");
      if (i === 2 || i >= 5) td.className = "num";
      if (i === 3) td.className = "mono";
      if (i === 4) {
        const span = document.createElement("span"); span.className = "branch-cell";
        const sw = document.createElement("span"); sw.className = "status-dot"; sw.style.background = slotVar(r); sw.style.borderRadius = "3px";
        const lab = document.createElement("span"); lab.textContent = BRANCH_NAMES[r];
        span.append(sw, lab); td.append(span);
      } else td.textContent = c;
      tr.append(td);
    });
    tb.append(tr);
  }
}

function renderDivergence() {
  const d2 = S.series.div2, d3 = S.series.div3;
  const maxV = Math.max(4, ...d2.map((p) => p[1]), ...d3.map((p) => p[1]));
  const series = [{ name: "Branch 2", color: "var(--series-2)", points: d2, label: (v) => `branch 2 · ${v}` }];
  if (d3.some((p) => p[1] > 0)) series.push({ name: "Other branches", color: "var(--series-3)", points: d3, label: (v) => `other · ${v}` });
  lineChart($("#chart-div"), { series, yMax: niceMax(maxV), yFmt: (v) => String(Math.round(v)), tipFmt: (v) => `${v} blocks` });
  const lg = $("#div-legend"); lg.replaceChildren();
  for (const s of series) {
    const k = document.createElement("span"); k.className = "key";
    const ln = document.createElement("span"); ln.className = "ln"; ln.style.background = s.color;
    const l = document.createElement("span"); l.textContent = s.name;
    k.append(ln, l); lg.append(k);
  }
}

function renderOrphan() {
  const pts = S.series.orphan;
  const ref = 1 - Math.exp(-INFO.latency / INFO.block_time);
  const maxV = Math.max(ref * 1.6, ...pts.map((p) => p[1]), 0.05);
  lineChart($("#chart-orphan"), {
    series: [{ name: "Orphan rate", color: "var(--series-1)", points: pts, label: (v) => `${(v * 100).toFixed(1)}%` }],
    refs: [{ label: `1−e^(−Δ/T) ${(ref * 100).toFixed(1)}%`, points: [[0, ref], [INFO.duration, ref]] }],
    yMax: niceMax(maxV), yFmt: (v) => `${+(v * 100).toFixed(1)}%`, tipFmt: (v) => `${(v * 100).toFixed(2)}%`,
  });
}

function renderReorgs() {
  const W = 620, H = 210, M = { l: 40, r: 74, t: 14, b: 22 };
  const c = $("#chart-reorg");
  let svg = c.querySelector("svg");
  if (!svg) { svg = el("svg", { role: "img" }); c.append(svg); }
  const maxD = Math.max(4, ...S.reorgs.map((r) => r.depth));
  const yMax = niceMax(maxD);
  const { x, y } = frame(svg, W, H, M, yMax, (v) => String(Math.round(v)));
  // aggregate: deepest reorg per pixel column so dense natural forks do not overdraw
  const cols = new Map();
  for (const r of S.reorgs) {
    const px = Math.round(x(r.t) / 5) * 5;
    const cur = cols.get(px);
    if (!cur || r.depth > cur.depth) cols.set(px, { ...r, nodes: cur ? [...cur.nodes, r.node] : [r.node], n: (cur?.n || 0) + 1 });
    else { cur.nodes.push(r.node); cur.n++; }
  }
  for (const [px, r] of cols) {
    const top = y(r.depth), base = y(0), w = 4;
    const path = `M${px - w / 2},${base} V${top + 2} q0,-2 2,-2 q2,0 2,2 V${base} Z`;
    const p = el("path", { d: path, class: "bar" }, svg);
    const hit = el("rect", { x: px - 6, y: M.t, width: 12, height: base - M.t, fill: "transparent" }, svg);
    hit.addEventListener("pointermove", (evt) => showTip(evt, `t ≈ ${Math.round(r.t)} s`, [
      { value: `${r.depth} blocks`, name: `deepest (${r.node})` },
      { value: String(r.n), name: `reorg events here: ${[...new Set(r.nodes)].join(", ")}` }]));
    hit.addEventListener("pointerleave", hideTip);
    void p;
  }
  if (S.reorgs.length) {
    const deepest = S.reorgs.reduce((a, b) => (b.depth > a.depth ? b : a));
    text(svg, Math.min(x(deepest.t) + 6, W - M.r + 4), y(deepest.depth) + 4, `${deepest.depth} · ${deepest.node}`, "end-label");
  } else text(svg, M.l + 8, y(yMax * 0.62), "no reorganisations yet", "empty");
}

function renderFFG() {
  const c = $("#chart-ffg");
  let svg = c.querySelector("svg");
  if (!svg) { svg = el("svg", { role: "img" }); c.append(svg); }
  svg.replaceChildren();
  const W = 620, M = { l: 52, r: 10, t: 16, b: 22 };
  if (!INFO.ffg) { svg.setAttribute("viewBox", `0 0 ${W} 60`); text(svg, 10, 30, "This scenario runs without Casper FFG.", "empty"); return; }
  const ids = nodeIds().filter((id) => INFO.nodes[id].role === "honest");
  const epochs = Math.floor(INFO.duration / INFO.ffg.epoch_length);
  const cell = Math.max(4, Math.min(16, (W - M.l - M.r - 190) / epochs));
  const rowH = 14, H = M.t + rowH * (ids.length + 1) + M.b + 6;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  const steps = ["--seq-0", "--seq-1", "--seq-2", "--seq-3", "--seq-4", "--seq-5", "--seq-6"];
  const color = (lag) => `var(${steps[Math.min(steps.length - 1, Math.max(0, lag - 1))]})`;
  ids.forEach((id, r) => {
    text(svg, M.l - 6, M.t + r * rowH + 10, id, "row-label");
    for (const s of S.ffg[id] || []) {
      const rc = el("rect", { x: M.l + (s.epoch - 1) * cell, y: M.t + r * rowH, width: cell - 1, height: rowH - 1,
                              rx: 2, class: "cell", fill: color(s.lag) }, svg);
      rc.addEventListener("pointermove", (evt) => showTip(evt, `${id} · epoch ${s.epoch}`, [
        { value: `${s.lag} epochs`, name: "finality lag" },
        { value: `${s.voting.toFixed(0)} / ${s.active.toFixed(0)} ETH`, name: "voting / active stake (this view)" },
        ...(s.leaking ? [{ value: "▲", name: "inactivity leak" }] : [])]));
      rc.addEventListener("pointerleave", hideTip);
    }
  });
  // leak row (status: warning, with icon)
  const ly = M.t + ids.length * rowH + 4;
  text(svg, M.l - 6, ly + 10, "leak ▲", "row-label");
  const leakEpochs = new Map(); // epoch -> number of node views leaking
  for (const id of ids) for (const s of S.ffg[id] || []) if (s.leaking) leakEpochs.set(s.epoch, (leakEpochs.get(s.epoch) || 0) + 1);
  for (const [ep, k] of leakEpochs) {
    const rc = el("rect", { x: M.l + (ep - 1) * cell, y: ly + 3, width: cell - 1, height: 6, rx: 2, class: "leak" }, svg);
    rc.addEventListener("pointermove", (evt) => showTip(evt, `epoch ${ep}`, [{ value: `${k} of ${ids.length}`, name: "node views leaking" }]));
    rc.addEventListener("pointerleave", hideTip);
  }
  for (let e = 0; e <= epochs; e += 10) text(svg, M.l + e * cell, H - 6, `ep ${e}`, "tick");
  // sequential legend
  const lgx = W - M.r - 7 * 16 - 52, lgy = M.t;
  text(svg, lgx - 6, lgy + 8, "lag (epochs)", "tick", { "text-anchor": "end" });
  steps.forEach((st, i) => el("rect", { x: lgx + i * 16, y: lgy, width: 15, height: 9, rx: 2, fill: `var(${st})` }, svg));
  text(svg, lgx, lgy + 21, "1", "tick"); text(svg, lgx + 7 * 16 - 2, lgy + 21, "7+", "tick", { "text-anchor": "end" });
}

function renderLog() {
  const ol = $("#log"); ol.replaceChildren();
  for (const l of S.log.slice(-60).reverse()) {
    const li = document.createElement("li");
    const t = document.createElement("span"); t.className = "t"; t.textContent = `${l.t.toFixed(1)} s`;
    const x = document.createElement("span"); x.textContent = l.text;
    li.append(t, x); ol.append(li);
  }
}

let CAPTIONS = null;
function renderCaption() {
  const box = $("#caption");
  if (!CAPTIONS) { box.hidden = true; return; }
  let cur = null;
  for (const c of CAPTIONS) if (c.t <= tNow) cur = c;
  box.hidden = !cur;
  if (cur && box.textContent !== cur.text) box.textContent = cur.text;
}

function renderAll() {
  if (!S) return;
  renderCaption();
  const br = branches();
  $("#clock-t").textContent = `t = ${tNow.toFixed(0)} s of ${INFO.duration} s`;
  $("#clock-epoch").textContent = INFO.ffg ? `epoch ${Math.floor(tNow / INFO.ffg.epoch_length)}` : "";
  $("#mode-chip").textContent = S.partition ? "partitioned" : S.eclipse ? "eclipse" : "";
  $("#scrubber").value = String(Math.round((tNow / INFO.duration) * 1000));
  renderKPIs(br); renderAlarms(br); renderGraph(br); renderTable(br);
  renderDivergence(); renderReorgs(); renderOrphan(); renderFFG(); renderLog();
}

// ------------------------------------------------------------------ playback
let lastFrame = null, lastRender = 0;
function tick(ts) {
  if (playing && lastFrame !== null) {
    const dt = (ts - lastFrame) / 1000;
    const target = Math.min(INFO.duration, tNow + dt * speed);
    seek(target);
    if (target >= INFO.duration && !LIVE) setPlaying(false);
  }
  lastFrame = ts;
  if (ts - lastRender > 90) { renderAll(); lastRender = ts; }
  requestAnimationFrame(tick);
}
function setPlaying(p) {
  playing = p;
  const b = $("#play"); b.textContent = p ? "Pause" : "Play"; b.setAttribute("aria-pressed", String(p));
}

function load(events, label) {
  EVENTS = events;
  INFO = events.find((e) => e.type === "scenario");
  EVENTS_ACTIONS = events.filter((e) => e.type === "action" && e.kind !== "tx");
  $("#scenario-desc").textContent = `${INFO.name} — ${INFO.description || ""}`.trim();
  document.title = `${INFO.name} · Partition Playground`;
  const svg = $("#graph"); svg.replaceChildren(); svg._layers = null; svg._nodes = null;
  S = null; tNow = 0; seek(0); renderAll();
  void label;
}

function parseJSONL(txt) { return txt.split("\n").filter((l) => l.trim()).map((l) => JSON.parse(l)); }

let LIVE = false;
function startLive(name, spd) {
  // server-sent events: the engine runs the scenario and paces the stream in (scaled) real time
  LIVE = true; EVENTS = []; let started = false;
  const es = new EventSource(`/stream?scenario=${encodeURIComponent(name)}&speed=${spd}`);
  es.onmessage = (m) => {
    const e = JSON.parse(m.data);
    EVENTS.push(e);
    if (e.type === "scenario" && !started) { started = true; load(EVENTS, name); setPlaying(true); }
    if (started) { while (cursor < EVENTS.length) apply(EVENTS[cursor++]); tNow = e.t; }
    if (e.type === "end") es.close();
  };
}

async function init() {
  const params = new URLSearchParams(location.search);
  if (params.get("theme")) document.documentElement.dataset.theme = params.get("theme");
  $("#theme-toggle").textContent = document.documentElement.dataset.theme === "dark" ? "Light" : "Dark";
  $("#theme-toggle").onclick = () => {
    const d = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = d; $("#theme-toggle").textContent = d === "dark" ? "Light" : "Dark";
  };
  $("#play").onclick = () => { if (INFO && tNow >= INFO.duration) seek(0); setPlaying(!playing); };
  $("#speed").onchange = (e) => { speed = +e.target.value; };
  $("#scrubber").oninput = (e) => { if (!INFO || LIVE) return; seek((+e.target.value / 1000) * INFO.duration); renderAll(); };
  $("#file-input").onchange = async (e) => { const f = e.target.files[0]; if (f) load(parseJSONL(await f.text()), f.name); };
  if (params.get("speed")) { speed = +params.get("speed"); $("#speed").value = params.get("speed"); }
  if (params.get("mode") === "video") document.body.classList.add("video");
  if (params.get("captions")) {
    try { CAPTIONS = await (await fetch(`captions/${params.get("captions")}.json`)).json(); } catch { CAPTIONS = null; }
  }

  let index = [];
  try { index = await (await fetch("data/index.json")).json(); } catch { /* opened without a server */ }
  const sel = $("#scenario-select");
  for (const it of index) { const o = document.createElement("option"); o.value = it.file; o.textContent = it.name; sel.append(o); }
  sel.onchange = async () => { setPlaying(false); load(parseJSONL(await (await fetch(`data/${sel.value}`)).text()), sel.value); };

  if (params.get("live")) startLive(params.get("live"), params.get("speed") || speed);
  else {
    const want = params.get("data") || (index[0] && index[0].file);
    if (want) {
      sel.value = want;
      load(parseJSONL(await (await fetch(`data/${want}`)).text()), want);
      if (params.get("t")) { seek(+params.get("t")); renderAll(); }
      if (params.get("autoplay")) setPlaying(true);
    }
  }
  requestAnimationFrame(tick);
}
init();
