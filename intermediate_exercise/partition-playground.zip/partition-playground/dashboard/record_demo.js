// Records the <= 3 min demo of the eclipse scenario.
//   python -m playground.serve --port 8765 &      (in the repo root)
//   node dashboard/record_demo.js && ffmpeg -i rec/*.webm -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p report/eclipse_demo.mp4
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1920, height: 1080 },
                                   recordVideo: { dir: 'rec', size: { width: 1920, height: 1080 } } });
  const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('http://127.0.0.1:8765/?data=eclipse.jsonl&mode=video&captions=eclipse&speed=8');
  await p.waitForTimeout(3000);                 // title frame
  await p.click('#play');
  await p.waitForFunction(() => document.querySelector('#play').textContent === 'Play', null, { timeout: 200000, polling: 500 });
  await p.waitForTimeout(4000);                 // hold the final state
  await ctx.close(); await b.close();
  console.log('errors:', errs.length ? errs : 'none');
})();
