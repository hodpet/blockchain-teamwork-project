# Team plan: roles, ownership, milestones

The rubric awards a point for teamwork evidence. That evidence has to be **yours**: per-role
branches and PRs, reviews, and the commit history. The tables below suggest a split along the
three roles so each person owns, reviews and can defend one part.

| Role | Owns | Reviews |
|---|---|---|
| Protocol engineer | `playground/engine.py`, `vclock.py`, `ffg.py`, `speedups.py`, scenario YAMLs | metrics definitions |
| Test & security lead | `tests/test_scenarios.py`, `playground/metrics.py`, `expect:` blocks, CI, orphan-rate band | engine changes |
| Frontend / integration | `dashboard/`, `playground/serve.py`, `export.py`, demo video, report figures | event-stream schema |

## Milestones

- **M1: scenario format and engine, two scenarios.** Virtual clock; `Scenario` YAML; partition,
  heal and eclipse actions; `partition_50_50` and `eclipse`. Definition of done: deterministic
  across `PYTHONHASHSEED`.
- **M2: metrics, remaining scenarios, tests.** `metrics.py`; `partition_70_30`, `high_latency`,
  `orphan_rate` (with a documented band), `ffg_offline_40` (with asserted epochs); CI under 60 s.
- **M3: dashboard, report, video.** Dashboard with replay and live modes; ≤ 6-page report; ≤ 3 min
  eclipse video.
- **Stretch.** Equivocating validator with gossiped slashing evidence; long partition showing
  conflicting finality.

## Before submitting, check that you can each explain

- Why the 50/50 FFG run does not finalise, and why the long partition eventually does, on both sides.
- Where the −1 pp systematic offset in the orphan-rate band comes from.
- Why the eclipse victim never finalises the attacker chain, but still loses its payment.
- What the four engine deviations from Lab 03 are, and why none of them changes a result.
