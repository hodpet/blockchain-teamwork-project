"""Scenario tests with asserted, explainable outcomes.

Each scenario's YAML carries an `expect:` block; the tests below assert those values, so the
YAML is both the experiment description and its specification. Every simulation is seeded and
runs on a virtual clock - the whole file finishes well under 60 s.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import subprocess
import sys
from pathlib import Path

import pytest

from playground import metrics as M
from playground.engine import SCENARIO_DIR, Scenario, run_scenario, run_sweep
from consensus import pos
from consensus.pos import Attestation, Checkpoint
from playground import speedups
from playground.ffg import NodeBeacon, predict_leak_recovery
from playground.vclock import run_virtual

ROOT = Path(__file__).resolve().parent.parent
_cache: dict[str, object] = {}


def sim(name: str, **overrides):
    key = name + json.dumps(overrides, sort_keys=True)
    if key not in _cache:
        _cache[key] = run_scenario(name, **overrides)
    return _cache[key]


def expect(name: str) -> dict:
    return Scenario.load(name).expect


def ffg_series(res, node, field="finalized"):
    return {e["epoch"]: e[field] for e in M.ffg_by_node(res.events)[node]}


def epoch_at(res, t: float) -> int:
    return int(t // res.scenario.ffg["epoch_length"])


def snapshots_between(res, t0, t1):
    return [e for e in res.of("snapshot") if t0 <= e["t"] <= t1]


# =========================================================================== engine


def test_every_scenario_file_loads_and_documents_its_expectation():
    files = sorted(SCENARIO_DIR.glob("*.yaml"))
    assert len(files) >= 5
    for f in files:
        sc = Scenario.load(f)
        assert sc.description and sc.expect, f.name


def test_virtual_clock_is_instant_and_exact():
    import asyncio
    import time

    async def main():
        loop = asyncio.get_running_loop()
        await asyncio.sleep(86_400)
        return loop.time()

    t0 = time.perf_counter()
    assert run_virtual(main()) == 86_400
    assert time.perf_counter() - t0 < 0.5


def test_same_seed_same_event_stream_different_seed_different():
    a = run_scenario("partition_50_50").events
    b = run_scenario("partition_50_50").events
    c = run_scenario("partition_50_50", seed=12).events
    assert a == b
    assert a != c


def test_deterministic_across_processes_and_hash_seeds(tmp_path):
    """Lab 03 seeds miners from hash(node_id), which differs per process; the engine must not."""
    digests = set()
    for hs in ("0", "1", "4242"):
        out = tmp_path / f"run{hs}.jsonl"
        env = {**os.environ, "PYTHONHASHSEED": hs, "PYTHONPATH": str(ROOT)}
        subprocess.run([sys.executable, "-m", "playground.engine", "partition_70_30", "-o", str(out)],
                       cwd=ROOT, env=env, check=True, capture_output=True)
        digests.add(hashlib.sha256(out.read_bytes()).hexdigest())
    assert len(digests) == 1


def test_lab03_code_is_used_unchanged():
    from consensus import network

    from playground.engine import PlaygroundNetwork, PlaygroundNode
    assert issubclass(PlaygroundNode, network.Node) and issubclass(PlaygroundNetwork, network.Network)
    assert issubclass(NodeBeacon, pos.BeaconState)
    # the reused Lab 03 logic: gossip/fork choice/reconciliation are inherited, not re-implemented
    for name in ("_handle_block", "_absorb_chain", "mine_forever", "submit_transaction"):
        assert getattr(PlaygroundNode, name) is getattr(network.Node, name)
    for name in ("_process_justification", "_process_finalization", "_process_inactivity_leak",
                 "_apply_correlated_penalty", "supermajority_threshold"):
        assert getattr(NodeBeacon, name) is getattr(pos.BeaconState, name)


def test_lab03_sources_are_byte_identical_to_the_upload():
    """The consensus/ package is Lab 03 verbatim; pin it so accidental edits show up."""
    digests = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()[:16]
               for p in sorted((ROOT / "consensus").glob("*.py"))}
    pinned = json.loads((ROOT / "consensus" / "SHA256SUMS.json").read_text())
    assert digests == pinned


def test_block_hash_cache_matches_lab03_computation():
    res = sim("partition_50_50")
    blocks = list(res.registry.values())
    assert len(blocks) > 50
    assert all(b.hash == speedups.reference_hash(b) for b in blocks)


# =========================================================================== 1. 50/50 partition


def test_partition_50_50_both_sides_available_then_reorg_and_converge():
    res, exp = sim("partition_50_50"), expect("partition_50_50")
    t_part, t_heal = M.action_time(res.events, "partition"), M.action_time(res.events, "heal")
    groups = next(e for e in res.of("action") if e["kind"] == "partition")["groups"]
    before = snapshots_between(res, t_part - 10, t_part)[-1]
    during = snapshots_between(res, t_part, t_heal)[-1]
    # availability (the "A" in CAP): both halves keep extending their own chain
    for g in groups:
        assert min(during["heights"][n] for n in g) > max(before["heights"][n] for n in g)
    assert {during["tips"][n] for n in groups[0]}.isdisjoint({during["tips"][n] for n in groups[1]})
    # consistency is restored only by throwing one side's blocks away
    assert M.max_reorg_depth(res.events, t_from=t_heal) >= exp["reorg_after_heal_min_depth"]
    conv = M.convergence_time(res.events, after=t_heal)
    assert conv is not None and conv <= exp["converged_within_after_heal"]


def test_partition_50_50_ffg_halts_instead_of_forking():
    res = sim("partition_50_50")
    t_part, t_heal = M.action_time(res.events, "partition"), M.action_time(res.events, "heal")
    e_part, e_heal = epoch_at(res, t_part), epoch_at(res, t_heal)
    for node in res.honest():
        fin = ffg_series(res, node)
        frozen = {fin[e] for e in range(e_part + 1, e_heal + 1)}
        assert len(frozen) == 1, f"{node} finalised during the partition"
        assert fin[max(fin)] > fin[e_heal], f"{node} did not resume finality after heal"
    assert M.conflicting_finality(res.events) == []


# =========================================================================== 2. 70/30 partition


def test_partition_70_30_majority_unaffected_minority_reorgs():
    res, exp = sim("partition_70_30"), expect("partition_70_30")
    groups = next(e for e in res.of("action") if e["kind"] == "partition")["groups"]
    major, minor = groups
    assert len(major) == 7 and len(minor) == 3
    assert M.max_reorg_depth(res.events, nodes=major) <= exp["majority_max_reorg_depth"]
    assert M.max_reorg_depth(res.events, nodes=minor) >= exp["minority_reorg_min_depth"]


def test_partition_70_30_ffg_majority_finalises_minority_frozen():
    res = sim("partition_70_30")
    t_part, t_heal = M.action_time(res.events, "partition"), M.action_time(res.events, "heal")
    e_part, e_heal = epoch_at(res, t_part), epoch_at(res, t_heal)
    major, minor = next(e for e in res.of("action") if e["kind"] == "partition")["groups"]
    for node in major:  # 70 % >= 2/3: finality advances every epoch during the partition
        fin = ffg_series(res, node)
        assert all(fin[e] == e - 1 for e in range(e_part + 1, e_heal))
    for node in minor:  # 30 %: frozen, then catches up via justification proofs after heal
        fin = ffg_series(res, node)
        # epochs tallied entirely inside the partition (the heal epoch is tallied after the heal)
        assert len({fin[e] for e in range(e_part + 1, e_heal)}) == 1
        assert fin[max(fin)] == max(fin) - 1
    assert M.conflicting_finality(res.events) == []
    assert all(v == [] for v in res.events[-1]["reverted_finality"].values())


# =========================================================================== 3. eclipse


def test_eclipse_victim_double_spent():
    res, exp = sim("eclipse"), expect("eclipse")
    t0, t1 = M.action_time(res.events, "eclipse"), M.action_time(res.events, "end_eclipse")
    snaps = snapshots_between(res, t0 + 60, t1)
    assert all(s["tips"]["node9"] != s["tips"]["node0"] for s in snaps)  # victim diverges
    pay = [s["confs"]["payment_to_victim"]["node9"] for s in res.of("snapshot") if "confs" in s]
    assert max(pay) >= exp["payment_max_confirmations_min"]
    assert pay[-1] == exp["payment_confirmations_at_end"]
    final = res.of("snapshot")[-1]["confs"]
    assert final["conflicting_spend"]["node9"] > 0 and final["conflicting_spend"]["node0"] > 0
    assert M.max_reorg_depth(res.events, nodes=["node9"], t_from=t1) >= exp["victim_reorg_min_depth"]


def test_eclipse_finality_lag_is_the_alarm():
    res = sim("eclipse")
    t0, t1 = M.action_time(res.events, "eclipse"), M.action_time(res.events, "end_eclipse")
    e0, e1 = epoch_at(res, t0), epoch_at(res, t1)
    victim, honest = ffg_series(res, "node9"), ffg_series(res, "node0")
    lag = {e: e - victim[e] for e in victim}
    # every epoch tallied inside the eclipse adds one epoch of lag (e1 is tallied after it ends)
    assert all(lag[e + 1] == lag[e] + 1 for e in range(e0 + 1, e1 - 1))
    assert lag[e1 - 1] >= 10
    assert all(honest[e] == e - 1 for e in range(e0 + 1, e1))  # the rest of the network is fine
    assert victim[max(victim)] == honest[max(honest)]  # and the victim catches up afterwards


# =========================================================================== 4. latency sweep


def test_stale_rate_rises_with_latency_over_block_time():
    runs = run_sweep("high_latency")
    rates = [(p["latency"] / 10.0, M.stale_rate(r.events)["rate"]) for p, r in runs]
    values = [r for _, r in rates]
    assert values == sorted(values) and len(set(values)) == len(values)
    assert values[0] < 0.03 and values[-1] > 0.2
    for ratio, rate in rates:  # same order of magnitude as the Poisson-race estimate
        assert 0.6 * M.analytic_stale_rate(ratio) <= rate <= 1.1 * M.analytic_stale_rate(ratio)


# =========================================================================== 5. orphan-rate calibration


def test_orphan_rate_at_10_percent_delay_within_documented_band():
    res, exp = sim("orphan_rate"), expect("orphan_rate")
    assert math.isclose(M.analytic_stale_rate(0.1), exp["analytic"], abs_tol=1e-4)
    s = M.stale_rate(res.events)
    lo, hi = exp["band"]
    assert s["mined"] > 3000
    assert lo <= s["rate"] <= hi, s
    assert abs(s["rate"] - exp["refined_estimate"]) <= exp["refined_max_sigma"] * s["stderr"], s


# =========================================================================== 6. FFG, 40 % offline


def test_ffg_40_percent_offline_lag_grows_while_blocks_continue():
    res, exp = sim("ffg_offline_40"), expect("ffg_offline_40")
    e_last = exp["justified_again_epoch"]
    fin = ffg_series(res, "node0")
    jus = ffg_series(res, "node0", "justified")
    leak = ffg_series(res, "node0", "leaking")
    outage = epoch_at(res, M.action_time(res.events, "offline")) + 1  # first epoch without the 40 %
    assert fin[outage - 1] == exp["last_finalized_before_outage"]
    lags = [e - fin[e] for e in range(outage, exp["finalized_again_epoch"])]
    assert lags == list(range(lags[0], lags[0] + len(lags)))  # +1 every epoch
    # blocks keep coming: PoW height strictly increases across the outage, epoch by epoch
    heights = [s["heights"]["node0"] for s in res.of("snapshot")
               if outage * 40 <= s["t"] <= e_last * 40][::4]
    assert all(b > a for a, b in zip(heights, heights[1:]))
    assert min(e for e, lk in leak.items() if lk) == exp["leak_starts_epoch"]


def test_ffg_inactivity_leak_restores_finality_at_predicted_epoch():
    res, exp = sim("ffg_offline_40"), expect("ffg_offline_40")
    # the expected epochs are exactly what a bare Lab 03 BeaconState (no network) produces
    pred = predict_leak_recovery(10, offline=[6, 7, 8, 9], first_offline_epoch=10)
    assert pred["last_finalized_before"] == exp["last_finalized_before_outage"]
    assert pred["leak_starts"] == exp["leak_starts_epoch"]
    assert pred["justified_again"] == exp["justified_again_epoch"]
    assert pred["finalized_again"] == exp["finalized_again_epoch"]
    for node in res.honest():
        jus = ffg_series(res, node, "justified")
        fin = ffg_series(res, node)
        assert min(e for e in jus if e >= 10 and jus[e] == e) == exp["justified_again_epoch"]
        assert min(e for e in fin if e >= 10 and fin[e] > exp["last_finalized_before_outage"]) \
            == exp["finalized_again_epoch"]
    last = M.ffg_by_node(res.events)["node0"][-1]
    assert 3 * last["voting"] > 2 * last["active"]  # 6 x 32 ETH > 2/3 of the drained total


# =========================================================================== extra pathologies


def test_delayed_relay_raises_stale_rate():
    res, exp = sim("delayed_relay"), expect("delayed_relay")
    base = sim("delayed_relay", timeline=[])
    delta = M.stale_rate(res.events)["rate"] - M.stale_rate(base.events)["rate"]
    assert delta >= exp["stale_rate_increase_vs_no_delay_min"]


def test_equivocation_evidence_gossips_and_slashes():
    res, exp = sim("equivocation"), expect("equivocation")
    t = M.action_time(res.events, "equivocate")
    holders = {e["node"]: e["t"] for e in res.of("slashing_evidence")}
    others = [n for n in res.honest() if n != "node3"]
    assert set(others) <= set(holders)
    assert max(holders[n] for n in others) - t <= exp["evidence_reaches_all_honest_nodes_within"]
    idx = res.nodes["node0"].ffg.validators[3]
    for n in others:  # Lab 03 slashing applied in every view: slashed flag + 1/32 + correlated
        v = res.nodes[n].ffg.validators[3]
        assert v.slashed and v.balance < pos.MAX_EFFECTIVE_BALANCE
    assert idx.index == 3
    fin = ffg_series(res, "node0")
    assert fin[max(fin)] == max(fin) - 1  # finality continues with 90 % of the stake


def test_long_partition_leak_buys_liveness_with_safety():
    res, exp = sim("partition_long_ffg"), expect("partition_long_ffg")
    conflicts = M.conflicting_finality(res.events)
    assert len(conflicts) >= exp["ffg_conflicting_finality_min"]
    reverted = res.events[-1]["reverted_finality"]
    assert any(reverted.values())  # one half finalised checkpoints that are no longer canonical


# =========================================================================== unit tests


def test_analytic_estimate():
    assert math.isclose(M.analytic_stale_rate(0.1), 1 - math.exp(-0.1))
    assert round(M.analytic_stale_rate(0.1), 4) == 0.0952


def test_stale_rate_on_synthetic_events():
    ev = [{"t": 0, "type": "scenario", "block_time": 1.0, "nodes": {}, "genesis": "g"},
          {"t": 1, "type": "mined", "node": "a", "hash": "b1", "parent": "g", "height": 1},
          {"t": 1.1, "type": "mined", "node": "b", "hash": "x1", "parent": "g", "height": 1},
          {"t": 2, "type": "mined", "node": "a", "hash": "b2", "parent": "b1", "height": 2},
          {"t": 20, "type": "end", "tips": {"a": "b2", "b": "b2"}}]
    s = M.stale_rate(ev)
    assert (s["mined"], s["stale"]) == (3, 1)


def test_node_beacon_dedups_and_detects_double_votes_like_lab03():
    v = NodeBeacon(3, "g")
    src = Checkpoint(0, "g")
    a, b = Attestation(0, src, Checkpoint(1, "x")), Attestation(0, src, Checkpoint(1, "y"))
    assert v.receive(a) and not v.receive(a)  # gossip duplicate is not double-counted
    assert v.receive(b)
    assert [r for *_, r in v.evidence] == ["double_vote"]
    assert pos.find_violations(v.attestation_log) == [(a, b, "double_vote")]  # Lab 03 agrees
    v.process_epoch(1)
    assert v.validators[0].slashed


def test_node_beacon_epochs_equal_plain_lab03_beacon_state():
    """With everybody attesting in time, NodeBeacon and Lab 03's BeaconState are identical."""
    plain, ours = pos.BeaconState(10, "g"), NodeBeacon(10, "g")
    for e in range(1, 50):
        voters = [i for i in range(10) if e < 10 or i < 6]
        for st in (plain, ours):
            st.attest_many(pos.honest_attestations(st, st.current_justified, Checkpoint(e, f"r{e}"), voters))
            st.process_epoch(e)
        assert (plain.current_justified, plain.finalized) == (ours.current_justified, ours.finalized)
        assert [x.balance for x in plain.validators] == [x.balance for x in ours.validators]


def test_justification_proofs_are_verified_not_trusted():
    honest = NodeBeacon(3, "g")
    for e in (1, 2):
        honest.attest_many(pos.honest_attestations(honest, honest.current_justified, Checkpoint(e, f"r{e}")))
        honest.process_epoch(e)
    late = NodeBeacon(3, "g")
    assert late.import_proofs(honest.export_proofs())
    assert late.finalized == honest.finalized == Checkpoint(1, "r1")
    forged = [(Attestation(0, Checkpoint(0, "g"), Checkpoint(1, "evil")),)]  # 1 of 3 validators
    fresh = NodeBeacon(3, "g")
    assert not fresh.import_proofs(forged) and fresh.current_justified.epoch == 0
