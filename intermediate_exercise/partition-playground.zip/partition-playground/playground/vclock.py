"""Deterministic virtual time for asyncio.

Lab 03's network is written against asyncio (`asyncio.sleep` for latency and mining delays).
Running it on a normal event loop makes results depend on wall-clock time and CPU load.
`VirtualClockLoop` keeps the code unchanged but makes `loop.time()` virtual: whenever nothing
is ready to run, the clock jumps straight to the next scheduled timer instead of sleeping.

Consequences:
  * a 2000-second scenario runs as fast as the CPU can process its events;
  * the order of events depends only on the program and its seeded RNGs, so every run with
    the same seed produces exactly the same event stream.

Use it through `run_virtual(coro)`.
"""
from __future__ import annotations

import asyncio
import selectors
from collections.abc import Coroutine
from typing import Any


class _VirtualSelector(selectors.BaseSelector):
    """A selector that never waits on real I/O: select(timeout) advances virtual time."""

    def __init__(self, loop: "VirtualClockLoop") -> None:
        self._loop = loop
        self._keys: dict[int, selectors.SelectorKey] = {}

    def register(self, fileobj, events, data=None):
        fd = fileobj if isinstance(fileobj, int) else fileobj.fileno()
        key = selectors.SelectorKey(fileobj, fd, events, data)
        self._keys[fd] = key
        return key

    def unregister(self, fileobj):
        fd = fileobj if isinstance(fileobj, int) else fileobj.fileno()
        return self._keys.pop(fd)

    def modify(self, fileobj, events, data=None):
        self.unregister(fileobj)
        return self.register(fileobj, events, data)

    def select(self, timeout=None):
        if timeout is None:
            # Nothing is ready and no timer is pending: every task waits forever.
            raise RuntimeError("virtual clock deadlock: no runnable task and no pending timer")
        if timeout > 0:
            self._loop._advance(timeout)
        return []

    def get_map(self):
        return self._keys

    def close(self) -> None:
        self._keys.clear()


class VirtualClockLoop(asyncio.SelectorEventLoop):
    def __init__(self) -> None:
        self._vtime = 0.0
        super().__init__(selector=_VirtualSelector(self))

    def time(self) -> float:  # noqa: D401 - asyncio API
        return self._vtime

    def _advance(self, dt: float) -> None:
        self._vtime += dt


def run_virtual(coro: Coroutine[Any, Any, Any]) -> Any:
    """Run `coro` to completion on a fresh virtual-clock loop and return its result."""
    with asyncio.Runner(loop_factory=VirtualClockLoop) as runner:
        return runner.run(coro)
