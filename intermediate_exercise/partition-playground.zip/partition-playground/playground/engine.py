"""Partition Playground - scenario engine on top of Lab 03 (`consensus.network`, `consensus.pos`).

A scenario (YAML) describes the network, the adversaries and a timeline of actions. The engine
runs Lab 03's gossip nodes (PoW, heaviest-chain fork choice, getchain reconciliation) and
Lab 03's Casper FFG state machine (one BeaconState per node, see ffg.py) side by side, on a virtual clock, and records a JSON event stream
that metrics.py and the dashboard consume.

What is reused from Lab 03 unchanged: topology (`build_network`), Node message handling, gossip
flooding with dedup, fork choice, chain reconciliation, mining as an exponential race.
What the subclasses below add (the "laboratory"):

  PlaygroundNetwork   per-link latency, latency changes over time, eclipse filtering,
                      deliberately delayed relays, non-blocking delivery
  PlaygroundNode      seeded RNG (Lab 03 seeds from hash(node_id), which Python randomises per
                      process), event hooks on every chain change, FFG vote gossip, attacker
                      behaviour (private chain during an eclipse)

Run a scenario:   python -m playground.engine playground/scenarios/eclipse.yaml -o out.jsonl
"""
from __future__ import annotations

import argparse
import asyncio
import json
import math
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from consensus.chain import Transaction
from consensus.network import Message, Network, Node, build_network
from consensus.pos import Attestation, Checkpoint

from . import lab03_adapter as A
from . import speedups

speedups.install()
from .ffg import FFGTiming, NodeBeacon
from .vclock import run_virtual

SCENARIO_DIR = Path(__file__).parent / "scenarios"


def short(h: str) -> str:
    return h[:10]


# --------------------------------------------------------------------------- scenario model


@dataclass
class Scenario:
    name: str
    description: str = ""
    seed: int = 1
    duration: float = 600.0
    block_time: float = 10.0  # mean NETWORK block interval
    nodes: int = 10
    peers_per_node: int | str = 3  # int, or "all" for a full mesh
    latency: float = 0.5  # mean one-hop latency (Lab 03 jitter: U(0.5, 1.5) x latency)
    hash_power: dict[str, float] = field(default_factory=dict)
    links: list[dict] = field(default_factory=list)  # per-link latency overrides
    adversaries: list[dict] = field(default_factory=list)
    ffg: dict | None = None
    timeline: list[dict] = field(default_factory=list)
    snapshot_interval: float | None = None
    expect: dict = field(default_factory=dict)
    sweep: dict | None = None  # {param: [values]} - run once per value (see run_sweep)
    topology: dict[str, list[str]] | None = None  # explicit adjacency, overrides build_network

    @staticmethod
    def from_dict(d: dict) -> "Scenario":
        d = dict(d)
        known = Scenario.__dataclass_fields__
        unknown = set(d) - set(known)
        if unknown:
            raise ValueError(f"unknown scenario keys: {sorted(unknown)}")
        return Scenario(**d)

    @staticmethod
    def load(path: str | Path) -> "Scenario":
        p = Path(path)
        if not p.exists() and not p.suffix:
            p = SCENARIO_DIR / f"{p}.yaml"
        with open(p) as f:
            return Scenario.from_dict(yaml.safe_load(f))

    def with_overrides(self, **kw) -> "Scenario":
        d = {k: getattr(self, k) for k in self.__dataclass_fields__}
        d.update(kw)
        return Scenario(**d)


# --------------------------------------------------------------------------- event log


class EventLog:
    def __init__(self) -> None:
        self.events: list[dict] = []
        self.loop: asyncio.AbstractEventLoop | None = None

    def now(self) -> float:
        return round(self.loop.time(), 6) if self.loop else 0.0

    def emit(self, type_: str, **data: Any) -> None:
        self.events.append({"t": self.now(), "type": type_, **data})


# --------------------------------------------------------------------------- network


class PlaygroundNetwork(Network):
    """Lab 03 Network + per-link latency, eclipse filtering, delayed relays.

    deliver() is non-blocking: it checks reachability at send time (as Lab 03 does) and puts the
    message in flight as a background task. Lab 03 awaited the full latency inside broadcast(),
    which stalled the sending node (no mining, no inbox processing) for one hop per relay.
    """

    def __init__(self, latency: float, seed: int, log: EventLog) -> None:
        super().__init__(latency=latency, seed=seed)
        self.log = log
        self.link_latency: dict[frozenset, float] = {}
        self.eclipse: dict | None = None  # {"victim": id, "attackers": set}
        self.relay_delay: dict[str, float] = {}
        self.by_kind: dict[str, int] = {}

    def latency_of(self, a: str, b: str) -> float:
        return self.link_latency.get(frozenset((a, b)), self.latency)

    def can_reach(self, a: str, b: str) -> bool:
        if self.eclipse is not None:
            v, atk = self.eclipse["victim"], self.eclipse["attackers"]
            if (a == v and b not in atk) or (b == v and a not in atk):
                return False
        return super().can_reach(a, b)

    async def deliver(self, source: str, target: str, message: Message) -> None:
        if not self.can_reach(source, target):
            self.dropped += 1
            return
        delay = self.latency_of(source, target) * (0.5 + self.rng.random())
        if source in self.relay_delay and message.kind in ("block", "head") and \
                getattr(message.payload, "miner", None) != source:
            delay += self.relay_delay[source]
        # a timer, not a task: same semantics as Lab 03's sleep-then-put, far cheaper
        asyncio.get_running_loop().call_later(delay, self._arrive, target, message)

    def _arrive(self, target: str, message: Message) -> None:
        node = self.nodes.get(target)
        if node is not None:
            self.delivered += 1
            self.by_kind[message.kind] = self.by_kind.get(message.kind, 0) + 1
            node.inbox.put_nowait(message)  # inboxes are unbounded


# --------------------------------------------------------------------------- nodes


class PlaygroundNode(Node):
    def __init__(self, node_id: str, *, sim: "Simulation", role: str = "honest", **kw) -> None:
        super().__init__(node_id, **kw)
        self.sim = sim
        self.role = role
        self._rng = random.Random(f"{sim.scenario.seed}:{node_id}")  # deterministic, unlike hash()
        self.ffg: NodeBeacon | None = None
        self._sync_requested: set[tuple[str, int]] = set()
        self._wrap_chain()

    # ---- observe every chain mutation (mined, relayed or absorbed)
    def _wrap_chain(self) -> None:
        chain = self.chain
        original = chain.add_block

        def add_block(block, check_pow=True):
            before = chain.tip_hash
            moved = original(block, check_pow=check_pow)
            self.sim.registry.setdefault(A.block_hash(block), block)
            if moved:
                self.sim.on_tip_change(self, before, chain.tip_hash)
            return moved

        chain.add_block = add_block

    # ---- cheaper mempool handling when there is no traffic (same semantics)
    def _select_transactions(self, limit: int = 4):
        return super()._select_transactions(limit) if self.mempool else ()

    def _prune_mempool(self) -> None:
        if self.mempool:
            super()._prune_mempool()

    # ---- message handling
    async def handle(self, message: Message) -> None:
        if self.role == "attacker" and self.sim.eclipse_active and message.sender not in self.sim.coalition:
            # private chain: ignore (and never relay) anything from outside the coalition
            return
        if message.kind == "vote":
            await self._handle_vote(message)
            return
        if message.kind == "ffg_sync":
            if self.ffg is not None and self.ffg.import_proofs(message.payload):
                self.sim.log.emit("ffg_sync", node=self.node_id, sender=message.sender,
                                  justified=self.ffg.current_justified.epoch,
                                  finalized=self.ffg.finalized.epoch)
            return
        if message.kind in ("getchain", "ffg_getsync") and self.ffg is not None and \
                not (self.role == "attacker" and self.sim.eclipse_active):
            # justification travels with the chain (in real FFG the votes are on-chain)
            await self.network.deliver(self.node_id, message.sender,
                                       Message("ffg_sync", self.ffg.export_proofs(), self.node_id))
            if message.kind == "ffg_getsync":
                return
        await super().handle(message)

    async def _handle_vote(self, message: Message) -> None:
        vote: Attestation = message.payload
        if self.ffg is None:
            return
        src = vote.source
        if src not in self.ffg.justified and src.epoch > self.ffg.current_justified.epoch \
                and (message.sender, src.epoch) not in self._sync_requested:
            # like Lab 03's unknown-parent getchain: ask the sender for justification proofs
            self._sync_requested.add((message.sender, src.epoch))
            await self.network.deliver(self.node_id, message.sender,
                                       Message("ffg_getsync", src.epoch, self.node_id))
        before = len(self.ffg.evidence)
        if self.ffg.receive(vote):
            if len(self.ffg.evidence) > before:
                a, _b, rule = self.ffg.evidence[-1]
                self.sim.log.emit("slashing_evidence", node=self.node_id,
                                  validator=self.sim.validator_node[a.validator],
                                  epoch=a.target.epoch, rule=rule)
            await self.broadcast(message, exclude=message.sender)

    async def broadcast(self, message: Message, *, exclude: str | None = None) -> None:
        if self.role == "attacker" and self.sim.eclipse_active:
            # attackers only talk to the coalition (incl. the victim) during the eclipse
            for peer in self.peers:
                if peer != exclude and peer in self.sim.coalition:
                    await self.network.deliver(self.node_id, peer, message)
            return
        await super().broadcast(message, exclude=exclude)

    async def run(self) -> None:  # event-driven; Lab 03 polls with a 0.1 s timeout
        self.running = True
        while self.running:
            message = await self.inbox.get()
            await self.handle(message)


# --------------------------------------------------------------------------- simulation


@dataclass
class SimResult:
    scenario: Scenario
    events: list[dict]
    nodes: dict[str, PlaygroundNode]
    network: PlaygroundNetwork
    registry: dict[str, Any]

    def converged(self) -> bool:
        return len({n.tip_hash for n in self.nodes.values()}) == 1

    def honest(self) -> dict[str, PlaygroundNode]:
        return {k: n for k, n in self.nodes.items() if n.role == "honest"}

    def of(self, type_: str) -> list[dict]:
        return [e for e in self.events if e["type"] == type_]

    def write_jsonl(self, path: str | Path) -> None:
        with open(path, "w") as f:
            for e in self.events:
                f.write(json.dumps(e, separators=(",", ":")) + "\n")


class Simulation:
    def __init__(self, scenario: Scenario) -> None:
        self.scenario = scenario
        self.log = EventLog()
        self.registry: dict[str, Any] = {}
        self.eclipse_active = False
        self.coalition: set[str] = set()
        self.offline_validators: set[str] = set()
        self.original_peers: dict[str, list[str]] = {}
        self.tasks: list[asyncio.Task] = []
        self.watched: dict[str, str] = {}  # label -> txid
        self.equivocators: set[str] = set()
        self._build()

    # ---- construction
    def _build(self) -> None:
        sc = self.scenario
        ppn = sc.nodes - 1 if sc.peers_per_node == "all" else int(sc.peers_per_node)
        base_net, base_nodes = build_network(sc.nodes, peers_per_node=ppn, latency=sc.latency, seed=sc.seed)
        genesis = next(iter(base_nodes.values())).chain.canonical()[0]
        self.genesis = genesis
        self.balances = dict(next(iter(base_nodes.values())).initial_balances)
        self.network = PlaygroundNetwork(sc.latency, sc.seed, self.log)
        self.nodes: dict[str, PlaygroundNode] = {}
        for nid, bn in base_nodes.items():
            n = PlaygroundNode(nid, sim=self, initial_balances=self.balances, genesis=genesis,
                               hash_power=float(sc.hash_power.get(nid, 1.0)))
            n.peers = list(bn.peers)
            self.nodes[nid] = n
            self.network.register(n)
        self.registry[A.block_hash(genesis)] = genesis
        rng = random.Random(f"{sc.seed}:adversaries")
        honest_ids = sorted(self.nodes)
        for adv in sc.adversaries:
            nid = adv["id"]
            n = PlaygroundNode(nid, sim=self, role=adv.get("role", "attacker"),
                               initial_balances=self.balances, genesis=genesis,
                               hash_power=float(adv.get("hash_power", 1.0)))
            k = int(adv.get("peers", 3))
            n.peers = sorted(rng.sample(honest_ids, k))
            for p in n.peers:
                self.nodes[p].peers = sorted(set(self.nodes[p].peers) | {nid})
            self.nodes[nid] = n
            self.network.register(n)
        if sc.topology is not None:  # explicit adjacency (made symmetric)
            adj = {nid: set() for nid in self.nodes}
            for a, peers in sc.topology.items():
                for b in peers:
                    adj[a].add(b)
                    adj[b].add(a)
            for nid, peers in adj.items():
                self.nodes[nid].peers = sorted(peers, key=_natural)
        for link in sc.links:
            self.network.link_latency[frozenset((link["a"], link["b"]))] = float(link["latency"])

        # FFG: one Lab 03 validator (32 ETH) per honest node; every node keeps its own BeaconState
        self.ffg_params = None
        if sc.ffg is not None:
            self.ffg_params = FFGTiming(**sc.ffg)
            hosts = sorted((n for n in self.nodes if self.nodes[n].role == "honest"), key=_natural)
            self.validator_index = {nid: i for i, nid in enumerate(hosts)}  # host node -> index
            self.validator_node = {i: nid for nid, i in self.validator_index.items()}
            for n in self.nodes.values():
                n.ffg = NodeBeacon(len(hosts), A.block_hash(genesis))

    # ---- hooks
    def common_ancestor_height(self, a: str, b: str) -> int:
        reg = self.registry
        ba, bb = reg[a], reg[b]
        while A.block_height(ba) > A.block_height(bb):
            ba = reg[A.block_parent(ba)]
        while A.block_height(bb) > A.block_height(ba):
            bb = reg[A.block_parent(bb)]
        while A.block_hash(ba) != A.block_hash(bb):
            ba, bb = reg[A.block_parent(ba)], reg[A.block_parent(bb)]
        return A.block_height(ba)

    def on_tip_change(self, node: PlaygroundNode, before: str, after: str) -> None:
        blk = self.registry[after]
        if A.block_miner(blk) == node.node_id and A.block_parent(blk) == before:
            self.log.emit("mined", node=node.node_id, hash=short(after),
                          parent=short(A.block_parent(blk)), height=A.block_height(blk))
        old_h = A.block_height(self.registry[before])
        depth = 0 if A.block_parent(blk) == before else old_h - self.common_ancestor_height(before, after)
        self.log.emit("tip", node=node.node_id, hash=short(after), height=A.block_height(blk),
                      depth=depth)

    # ---- helpers
    def resolve_groups(self, spec) -> list[set[str]]:
        honest = [n for n in sorted(self.nodes, key=_natural) if self.nodes[n].role == "honest"]
        if isinstance(spec, dict) and "split" in spec:
            fracs = spec["split"]
            groups, start = [], 0
            for i, f in enumerate(fracs):
                end = len(honest) if i == len(fracs) - 1 else start + round(f * len(honest))
                groups.append(set(honest[start:end]))
                start = end
            return groups
        return [set(g) for g in spec]

    def checkpoint_hash(self, node: PlaygroundNode, epoch: int) -> str:
        """Canonical block of `node` with timestamp <= epoch start - margin."""
        p = self.ffg_params
        boundary = epoch * p.epoch_length - p.checkpoint_margin * p.epoch_length
        b = self.registry[node.tip_hash]
        while A.block_height(b) > 0 and A.block_timestamp(b) > boundary:
            b = self.registry[A.block_parent(b)]
        return A.block_hash(b)

    def tx_confirmations(self, node: PlaygroundNode, txid: str) -> int:
        b = self.registry[node.tip_hash]
        tip_h = A.block_height(b)
        while A.block_height(b) > 0:
            if any(t.txid == txid for t in b.txs):
                return tip_h - A.block_height(b) + 1
            b = self.registry[A.block_parent(b)]
        return 0

    # ---- actions
    async def do(self, act: dict) -> None:
        kind = next(k for k in act if k != "at")
        val = act[kind]
        log = self.log
        if kind == "partition":
            groups = self.resolve_groups(val)
            self.network.partition(groups)
            log.emit("action", kind="partition", groups=[sorted(g, key=_natural) for g in groups])
        elif kind == "heal":
            self.network.heal()
            log.emit("action", kind="heal")
            for n in self.nodes.values():  # Lab 03's reconciliation trigger
                await n.announce_head()
        elif kind == "latency":
            self.network.latency = float(val)
            log.emit("action", kind="latency", latency=float(val))
        elif kind == "eclipse":
            victim, attackers = val["victim"], list(val["attackers"])
            self.original_peers = {k: list(n.peers) for k, n in self.nodes.items()}
            for k, n in self.nodes.items():
                if k != victim and k not in attackers and victim in n.peers:
                    n.peers.remove(victim)
            self.nodes[victim].peers = sorted(attackers)
            for a in attackers:
                self.nodes[a].peers = sorted(set(self.nodes[a].peers) | {victim})
            self.network.eclipse = {"victim": victim, "attackers": set(attackers)}
            self.eclipse_active = True
            self.coalition = set(attackers) | {victim}
            log.emit("action", kind="eclipse", victim=victim, attackers=attackers)
        elif kind == "end_eclipse":
            for k, peers in self.original_peers.items():
                self.nodes[k].peers = peers
            self.network.eclipse = None
            self.eclipse_active = False
            log.emit("action", kind="end_eclipse")
            for n in self.nodes.values():
                await n.announce_head()
        elif kind == "relay_delay":
            self.network.relay_delay[val["node"]] = float(val["delay"])
            log.emit("action", kind="relay_delay", node=val["node"], delay=float(val["delay"]))
        elif kind == "offline":
            vals = self.resolve_groups([val])[0] if isinstance(val, list) else self.resolve_groups(val)[0]
            self.offline_validators |= vals
            log.emit("action", kind="offline", validators=sorted(vals, key=_natural))
        elif kind == "online":
            self.offline_validators -= set(val)
            log.emit("action", kind="online", validators=sorted(val, key=_natural))
        elif kind == "stop_mining":
            for nid in val:
                self.nodes[nid].hash_power = 0.0
            log.emit("action", kind="stop_mining", nodes=list(val))
        elif kind == "tx":
            # {to_node, sender, recipient, amount, nonce, label}
            tx = Transaction(sender=val["sender"], recipient=val["recipient"], amount=int(val["amount"]),
                             nonce=int(val.get("nonce", 0)), fee=int(val.get("fee", 1)))
            label = val.get("label", short(tx.txid))
            self.watched[label] = tx.txid
            ok = await self.nodes[val["to_node"]].submit_transaction(tx)
            log.emit("action", kind="tx", label=label, node=val["to_node"], accepted=ok)
        elif kind == "equivocate":
            await self._equivocate(val)
        else:
            raise ValueError(f"unknown action {kind!r}")

    async def _equivocate(self, val: dict) -> None:
        validator, epoch = val["validator"], int(val["epoch"])
        host = self.nodes[validator]
        idx, src = self.validator_index[validator], host.ffg.current_justified
        honest_target = self.checkpoint_hash(host, epoch)
        fake_target = "f" * 64  # a conflicting checkpoint nobody else votes for
        va = Attestation(idx, src, Checkpoint(epoch, honest_target))
        vb = Attestation(idx, src, Checkpoint(epoch, fake_target))
        self.equivocators.add(validator)
        half = len(host.peers) // 2
        for i, peer in enumerate(host.peers):
            await self.network.deliver(host.node_id, peer, Message("vote", va if i < half else vb, host.node_id))
        self.log.emit("action", kind="equivocate", validator=validator, epoch=epoch)

    # ---- periodic tasks
    async def _timeline(self) -> None:
        loop = asyncio.get_running_loop()
        for act in sorted(self.scenario.timeline, key=lambda a: a["at"]):
            await asyncio.sleep(max(0.0, act["at"] - loop.time()))
            await self.do(act)

    async def _snapshots(self) -> None:
        interval = self.scenario.snapshot_interval or self.scenario.block_time
        while True:
            snap = {"heights": {}, "tips": {}, "delivered": self.network.delivered,
                    "dropped": self.network.dropped}
            for nid in sorted(self.nodes, key=_natural):
                n = self.nodes[nid]
                snap["heights"][nid] = n.height
                snap["tips"][nid] = short(n.tip_hash)
            if self.watched:
                snap["confs"] = {lbl: {nid: self.tx_confirmations(n, txid)
                                       for nid, n in sorted(self.nodes.items())}
                                 for lbl, txid in self.watched.items()}
            self.log.emit("snapshot", **snap)
            await asyncio.sleep(interval)

    async def _ffg_epochs(self) -> None:
        p = self.ffg_params
        loop = asyncio.get_running_loop()
        epoch = 1
        while True:
            start = epoch * p.epoch_length
            await asyncio.sleep(max(0.0, start + p.vote_offset * p.epoch_length - loop.time()))
            for validator in sorted(self.validator_index, key=_natural):
                if validator in self.offline_validators or validator in self.equivocators:
                    continue
                host = self.nodes[validator]
                vote = Attestation(self.validator_index[validator], host.ffg.current_justified,
                                   Checkpoint(epoch, self.checkpoint_hash(host, epoch)))
                host.ffg.receive(vote)
                await host.broadcast(Message("vote", vote, host.node_id))
            await asyncio.sleep(max(0.0, start + p.tally_offset * p.epoch_length - loop.time()))
            for nid in sorted(self.nodes, key=_natural):
                n = self.nodes[nid]
                if n.ffg is None or n.role != "honest":
                    continue
                leaking = n.ffg.leaking(epoch)
                active, voting = n.ffg.active_eth(), n.ffg.voting_eth(epoch)
                r = n.ffg.process_epoch(epoch)
                self.log.emit("ffg", node=nid, epoch=epoch,
                              justified=n.ffg.current_justified.epoch,
                              finalized=n.ffg.finalized.epoch,
                              finalized_hash=short(n.ffg.finalized.root),
                              leaking=leaking, active=round(active, 6), voting=round(voting, 6),
                              slashed=sorted(self.validator_node[s.validator] for s in r["slashed"]))
            epoch += 1

    # ---- main
    async def _main(self) -> SimResult:
        sc = self.scenario
        loop = asyncio.get_running_loop()
        self.log.loop = loop
        total_hp = sum(n.hash_power for n in self.nodes.values()) or 1.0
        self.log.emit("scenario", name=sc.name, description=sc.description, seed=sc.seed,
                      duration=sc.duration, block_time=sc.block_time, latency=sc.latency,
                      nodes={k: {"role": n.role, "hash_power": n.hash_power,
                                 "peers": n.peers} for k, n in sorted(self.nodes.items(), key=lambda kv: _natural(kv[0]))},
                      ffg=None if self.ffg_params is None else self.ffg_params.__dict__,
                      genesis=short(A.block_hash(self.genesis)))
        for nid in sorted(self.nodes, key=_natural):
            n = self.nodes[nid]
            self.tasks.append(loop.create_task(n.run()))
        for nid in sorted(self.nodes, key=_natural):
            n = self.nodes[nid]
            if n.hash_power > 0:
                # Lab 03's rate = hash_power / mean_block_time; scale so the NETWORK rate = 1/T
                self.tasks.append(loop.create_task(n.mine_forever(sc.block_time * total_hp)))
        self.tasks.append(loop.create_task(self._timeline()))
        self.tasks.append(loop.create_task(self._snapshots()))
        if self.ffg_params is not None:
            self.tasks.append(loop.create_task(self._ffg_epochs()))
        await asyncio.sleep(sc.duration)
        for n in self.nodes.values():
            n.stop()
        for t in self.tasks:
            t.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        reverted_finality = {}  # finalised checkpoints no longer on the node's chain
        for k, n in sorted(self.nodes.items()):
            if n.ffg is not None and n.role == "honest":
                reverted_finality[k] = sorted(
                    c.epoch for c in n.ffg.finalized_history
                    if c.root not in self.registry
                    or self.common_ancestor_height(c.root, n.tip_hash) != A.block_height(self.registry[c.root]))
        self.log.emit("end", heights={k: n.height for k, n in sorted(self.nodes.items())},
                      reverted_finality=reverted_finality,
                      tips={k: short(n.tip_hash) for k, n in sorted(self.nodes.items())},
                      delivered=self.network.delivered, dropped=self.network.dropped,
                      by_kind=dict(sorted(self.network.by_kind.items())))
        return SimResult(sc, self.log.events, self.nodes, self.network, self.registry)

    def run(self) -> SimResult:
        return run_virtual(self._main())


def _natural(nid: str):
    head = nid.rstrip("0123456789")
    tail = nid[len(head):]
    return (head, int(tail) if tail else -1)


def run_scenario(scenario: Scenario | str | Path, **overrides) -> SimResult:
    sc = scenario if isinstance(scenario, Scenario) else Scenario.load(scenario)
    if overrides:
        sc = sc.with_overrides(**overrides)
    return Simulation(sc).run()


def run_sweep(scenario: Scenario | str | Path) -> list[tuple[dict, SimResult]]:
    """Run a scenario once per value of its `sweep` parameter(s) (cartesian product)."""
    import itertools

    sc = scenario if isinstance(scenario, Scenario) else Scenario.load(scenario)
    if not sc.sweep:
        return [({}, run_scenario(sc))]
    keys = list(sc.sweep)
    out = []
    for combo in itertools.product(*(sc.sweep[k] for k in keys)):
        params = dict(zip(keys, combo))
        out.append((params, run_scenario(sc.with_overrides(sweep=None, **params))))
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Run a Partition Playground scenario")
    ap.add_argument("scenario", help="YAML file or scenario name")
    ap.add_argument("-o", "--out", help="write the JSONL event stream here")
    ap.add_argument("--seed", type=int)
    args = ap.parse_args(argv)
    from . import metrics

    sc = Scenario.load(args.scenario)
    if args.seed is not None:
        sc = sc.with_overrides(seed=args.seed)
    for params, res in run_sweep(sc):
        if params:
            print(json.dumps(params))
        print(json.dumps(metrics.summary(res.events), indent=2))
        if args.out:
            suffix = "".join(f"_{k}{v}" for k, v in params.items())
            out = Path(args.out)
            res.write_jsonl(out.with_name(out.stem + suffix + out.suffix) if suffix else out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
