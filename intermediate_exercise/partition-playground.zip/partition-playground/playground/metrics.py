"""Metrics computed from the JSON event stream alone (the same stream the dashboard reads).

Definitions
  stale (orphan) rate   blocks mined that are NOT on the final canonical chain, divided by all
                        blocks mined, over a window that excludes the last few block times
                        (blocks there have not had time to be orphaned or confirmed).
  reorg depth           on a tip change to a non-descendant: old tip height - common ancestor
                        height (number of blocks the node un-confirmed).
  finality lag          current epoch - last finalised epoch, per node.
  convergence time      time after an action until all nodes (optionally a subset) share a tip.
"""
from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Iterable


def analytic_stale_rate(delay_over_block_time: float) -> float:
    """P(a competing block is found during the propagation delay) for a Poisson race."""
    return 1.0 - math.exp(-delay_over_block_time)


def _of(events: Iterable[dict], type_: str) -> list[dict]:
    return [e for e in events if e["type"] == type_]


def scenario_info(events) -> dict:
    return _of(events, "scenario")[0]


def final_tips(events) -> dict[str, str]:
    return _of(events, "end")[-1]["tips"]


def majority_tip(events, nodes: Iterable[str] | None = None) -> str:
    tips = final_tips(events)
    counts: dict[str, int] = defaultdict(int)
    for n, h in tips.items():
        if nodes is None or n in nodes:
            counts[h] += 1
    return max(sorted(counts), key=lambda h: counts[h])


def block_graph(events) -> dict[str, tuple[str, int, str, float]]:
    """hash -> (parent, height, miner, time) for every mined block."""
    return {e["hash"]: (e["parent"], e["height"], e["node"], e["t"]) for e in _of(events, "mined")}


def canonical_set(events, tip: str) -> set[str]:
    g = block_graph(events)
    out, h = set(), tip
    while h in g:
        out.add(h)
        h = g[h][0]
    return out


def stale_rate(events, *, exclude_tail_blocks: float = 5.0, t_from: float = 0.0,
               t_to: float | None = None, reference_nodes=None) -> dict:
    info = scenario_info(events)
    end_t = _of(events, "end")[-1]["t"]
    horizon = end_t - exclude_tail_blocks * info["block_time"]
    t_to = horizon if t_to is None else min(t_to, horizon)
    canon = canonical_set(events, majority_tip(events, reference_nodes))
    mined = [e for e in _of(events, "mined") if t_from <= e["t"] <= t_to]
    stale = [e for e in mined if e["hash"] not in canon]
    n = len(mined)
    rate = len(stale) / n if n else 0.0
    se = math.sqrt(rate * (1 - rate) / n) if n else 0.0
    return {"mined": n, "stale": len(stale), "rate": rate, "stderr": se}


def reorgs(events, nodes: Iterable[str] | None = None) -> list[dict]:
    nodes = set(nodes) if nodes is not None else None
    return [e for e in _of(events, "tip") if e["depth"] > 0 and (nodes is None or e["node"] in nodes)]


def max_reorg_depth(events, nodes=None, t_from: float = 0.0, t_to: float = math.inf) -> int:
    return max((e["depth"] for e in reorgs(events, nodes) if t_from <= e["t"] <= t_to), default=0)


def tips_timeline(events) -> list[tuple[float, dict[str, int], dict[str, str]]]:
    return [(e["t"], e["heights"], e["tips"]) for e in _of(events, "snapshot")]


def distinct_tips(events) -> list[tuple[float, int]]:
    return [(t, len(set(tips.values()))) for t, _, tips in tips_timeline(events)]


def action_time(events, kind: str, nth: int = 0) -> float | None:
    acts = [e for e in _of(events, "action") if e["kind"] == kind]
    return acts[nth]["t"] if len(acts) > nth else None


def convergence_time(events, after: float, nodes: Iterable[str] | None = None) -> float | None:
    """Seconds after `after` until all (selected) nodes share one tip, tracked from tip events."""
    info = scenario_info(events)
    nodes = sorted(nodes) if nodes is not None else sorted(info["nodes"])
    tip = {n: info["genesis"] for n in nodes}
    for e in events:
        if e["type"] == "tip" and e["node"] in tip:
            tip[e["node"]] = e["hash"]
            if e["t"] >= after and len(set(tip.values())) == 1:
                return e["t"] - after
        if e["type"] == "action" and e["t"] >= after and e["t"] == after and len(set(tip.values())) == 1:
            return 0.0
    return None


# ---- FFG


def ffg_by_node(events) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = defaultdict(list)
    for e in _of(events, "ffg"):
        out[e["node"]].append(e)
    return dict(out)


def finality_lag(events, node: str) -> list[tuple[int, int]]:
    return [(e["epoch"], e["epoch"] - e["finalized"]) for e in ffg_by_node(events).get(node, [])]


def finalized_epochs(events, node: str) -> list[int]:
    """Epochs (of processing) at which `node`'s finalised checkpoint advanced."""
    out, last = [], 0
    for e in ffg_by_node(events).get(node, []):
        if e["finalized"] > last:
            out.append(e["epoch"])
            last = e["finalized"]
    return out


def conflicting_finality(events) -> list[tuple[int, dict[str, str]]]:
    """Epochs at which two nodes finalised DIFFERENT checkpoints (a safety violation)."""
    by_epoch: dict[int, dict[str, str]] = defaultdict(dict)
    for e in _of(events, "ffg"):
        by_epoch[e["finalized"]][e["node"]] = e["finalized_hash"]
    return [(ep, hs) for ep, hs in sorted(by_epoch.items()) if len(set(hs.values())) > 1]


def summary(events) -> dict:
    info = scenario_info(events)
    end = _of(events, "end")[-1]
    s = {
        "scenario": info["name"],
        "seed": info["seed"],
        "blocks_mined": len(_of(events, "mined")),
        "stale_rate": round(stale_rate(events)["rate"], 4),
        "analytic_stale_rate(latency/T)": round(analytic_stale_rate(info["latency"] / info["block_time"]), 4),
        "max_reorg_depth": max_reorg_depth(events),
        "reorg_events": len(reorgs(events)),
        "converged_at_end": len(set(end["tips"].values())) == 1,
        "messages_delivered": end["delivered"],
        "messages_dropped": end["dropped"],
    }
    f = ffg_by_node(events)
    if f:
        node = sorted(f)[0]
        last = f[node][-1]
        s.update({"ffg_last_epoch": last["epoch"], "ffg_finalized": last["finalized"],
                  "ffg_finality_restored_epochs": finalized_epochs(events, node)[-3:],
                  "ffg_conflicting_finality": len(conflicting_finality(events))})
    ev = _of(events, "slashing_evidence")
    if ev:
        s["slashing_evidence_nodes"] = len({e["node"] for e in ev})
    return s
