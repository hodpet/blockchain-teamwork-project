"""Behaviour-preserving speed-ups for Lab 03 code, applied by the engine at import time.

`consensus.chain.Block` is a frozen dataclass whose `hash` property re-serialises the header to
JSON and double-SHA-256s it on every access (~190k times in a 1-hour simulated run). A block's
hash is a pure function of its immutable fields, so memoising it in the instance changes no
result; tests/test_scenarios.py checks the cached value against Lab 03's own computation.
Lab 03's source files are not modified.
"""
from __future__ import annotations

from consensus import chain
from consensus.chain import sha256d

_original_hash = chain.Block.hash  # the property object, kept for verification


def _cached_hash(self) -> str:
    h = self.__dict__.get("_pp_hash")
    if h is None:
        h = sha256d(self.header_bytes()).hex()
        object.__setattr__(self, "_pp_hash", h)  # frozen dataclass: bypass __setattr__
    return h


def install() -> None:
    if not getattr(chain.Block, "_pp_cached", False):
        chain.Block.hash = property(_cached_hash, doc=_original_hash.__doc__)
        chain.Block._pp_cached = True


def reference_hash(block: chain.Block) -> str:
    """Lab 03's uncached computation, for verification."""
    return _original_hash.fget(block)
