"""Serve the dashboard and a LIVE JSON event stream (server-sent events), stdlib only.

    python -m playground.serve --port 8000
    open http://localhost:8000/?live=eclipse&speed=20     # live, paced 20x faster than sim time
    open http://localhost:8000/?data=eclipse.jsonl         # replay a recorded stream

/stream?scenario=<name>&speed=<x> runs the scenario with the engine and emits each event when its
virtual timestamp is reached (wall clock = sim time / speed) - what an operator's collector would
see arriving from a running network.
"""
from __future__ import annotations

import argparse
import json
import time
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .engine import run_scenario

DASHBOARD = Path(__file__).resolve().parent.parent / "dashboard"


class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        url = urlparse(self.path)
        if url.path != "/stream":
            return super().do_GET()
        q = parse_qs(url.query)
        name = q.get("scenario", ["eclipse"])[0]
        speed = float(q.get("speed", ["20"])[0])
        if not name.replace("_", "").isalnum():
            self.send_error(400, "bad scenario name")
            return
        events = run_scenario(name).events
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        t0 = time.monotonic()
        try:
            for e in events:
                wait = e["t"] / speed - (time.monotonic() - t0)
                if wait > 0:
                    time.sleep(wait)
                self.wfile.write(f"data: {json.dumps(e, separators=(',', ':'))}\n\n".encode())
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, fmt, *args):  # quieter
        if "/stream" in (args[0] if args else ""):
            super().log_message(fmt, *args)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args(argv)
    srv = ThreadingHTTPServer(("127.0.0.1", args.port), partial(Handler, directory=str(DASHBOARD)))
    print(f"dashboard on http://127.0.0.1:{args.port}/  (live: /?live=eclipse&speed=20)")
    srv.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
