"""Write every scenario's event stream to dashboard/data/ (+ index.json) for the dashboard.

    python -m playground.export            # all scenarios
    python -m playground.export eclipse    # just one
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from .engine import SCENARIO_DIR, Scenario, run_sweep

OUT = Path(__file__).resolve().parent.parent / "dashboard" / "data"
ORDER = ["eclipse", "partition_50_50", "partition_70_30", "ffg_offline_40", "high_latency",
         "orphan_rate", "delayed_relay", "equivocation", "partition_long_ffg"]


def main(argv=None) -> int:
    names = (argv if argv is not None else sys.argv[1:]) or \
        sorted((p.stem for p in SCENARIO_DIR.glob("*.yaml")), key=lambda n: ORDER.index(n) if n in ORDER else 99)
    OUT.mkdir(parents=True, exist_ok=True)
    index = []
    for name in names:
        sc = Scenario.load(name)
        for params, res in run_sweep(sc):
            suffix = "".join(f"_{k}{v}" for k, v in params.items())
            fname = f"{name}{suffix}.jsonl"
            res.write_jsonl(OUT / fname)
            label = name.replace("_", " ") + (f" ({', '.join(f'{k}={v}' for k, v in params.items())})" if params else "")
            index.append({"file": fname, "name": label})
            print(f"{fname:40s} {len(res.events):6d} events  {(OUT / fname).stat().st_size / 1e6:5.2f} MB")
    if argv is None and not sys.argv[1:]:
        (OUT / "index.json").write_text(json.dumps(index, indent=1) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
