"""Casper FFG for the playground = Lab 03's `consensus.pos.BeaconState`, one per node.

Lab 03's state machine is used unchanged for everything consensus-relevant:
justification (> 2/3 of active effective balance from a justified source), finalisation
(a justified checkpoint whose successor epoch is justified), slashing (`is_double_vote`,
`is_surround_vote`, initial + correlated penalty) and the inactivity leak
(after MIN_EPOCHS_TO_INACTIVITY_PENALTY epochs without finality, each absent validator loses
effective_balance // INACTIVITY_PENALTY_QUOTIENT per epoch).

What `NodeBeacon` adds for a *networked* setting, where every node has its own view:
  * dedup: gossip can deliver an attestation more than once; Lab 03's `attest` appends blindly;
  * incremental slashing detection with Lab 03's own predicates (Lab 03 re-scans all pairs of
    the attestation log every epoch - quadratic, too slow over a long run; same result);
  * justification proofs: the attestations behind each justified checkpoint, so that a node that
    missed them (partition, eclipse) can verify and adopt them later. In Ethereum the votes are
    on-chain and travel with the blocks; here they travel with Lab 03's `getchain` reply.

Timing (epoch length, when validators vote, when nodes tally, how old a checkpoint must be) is a
simulation concern and lives in `FFGTiming`.
"""
from __future__ import annotations

from dataclasses import dataclass

from consensus import pos
from consensus.pos import Attestation, BeaconState, Checkpoint, is_double_vote, is_surround_vote

GWEI = pos.GWEI


@dataclass(frozen=True)
class FFGTiming:
    epoch_length: float = 40.0  # seconds (virtual)
    vote_offset: float = 0.25  # fraction of the epoch at which validators attest
    tally_offset: float = 0.95  # fraction of the epoch at which nodes run process_epoch
    checkpoint_margin: float = 0.5  # checkpoint = canonical block >= this many epochs old at the boundary


def attestation_id(a: Attestation) -> str:
    return f"att:{a.validator}:{a.source.epoch}:{a.source.root}:{a.target.epoch}:{a.target.root}"


class NodeBeacon(BeaconState):
    """One node's Casper FFG view (Lab 03 BeaconState + networking helpers)."""

    def __init__(self, validator_count: int, genesis_root: str) -> None:
        super().__init__(validator_count, genesis_root)
        self._seen: set[str] = set()
        self._by_validator: dict[int, list[Attestation]] = {}
        self.evidence: list[tuple[Attestation, Attestation, str]] = []
        self.proofs: dict[int, tuple[Attestation, ...]] = {}
        #: every checkpoint this view has ever finalised (Lab 03 keeps only the latest)
        self.finalized_history: list[Checkpoint] = [self.finalized]

    # ---- attestations
    def attest(self, attestation: Attestation) -> None:
        key = attestation_id(attestation)
        if key in self._seen:
            return
        self._seen.add(key)
        for other in self._by_validator.get(attestation.validator, []):
            if is_double_vote(other, attestation):
                self.evidence.append((other, attestation, "double_vote"))
            elif is_surround_vote(other, attestation) or is_surround_vote(attestation, other):
                self.evidence.append((other, attestation, "surround_vote"))
        self._by_validator.setdefault(attestation.validator, []).append(attestation)
        super().attest(attestation)

    def receive(self, attestation: Attestation) -> bool:
        """Gossip entry point. True if new (and therefore worth relaying)."""
        if attestation_id(attestation) in self._seen:
            return False
        self.attest(attestation)
        return True

    def _process_slashings(self, epoch: int):
        """Same penalties as Lab 03, driven by the incrementally collected evidence."""
        records = []
        already = {r.validator for r in self.slashings}
        for a, _b, rule in self.evidence:
            if a.validator in already:
                continue
            v = self.validators[a.validator]
            penalty = v.effective_balance // pos.INITIAL_SLASHING_QUOTIENT
            v.balance -= penalty
            v.slashed = True
            v.slashed_epoch = epoch
            self.slashed_balance_total += v.effective_balance
            rec = pos.SlashingRecord(a.validator, epoch, rule, penalty)
            records.append(rec)
            self.slashings.append(rec)
            already.add(a.validator)
        if records:
            self._apply_correlated_penalty(records)
        return records

    # ---- epoch processing with proof capture
    def process_epoch(self, epoch: int) -> dict[str, object]:
        justified_before = set(self.justified)
        result = super().process_epoch(epoch)
        if self.finalized != self.finalized_history[-1]:
            self.finalized_history.append(self.finalized)
        tgt = result["justified"]
        if tgt is not None:
            self.proofs[tgt.epoch] = tuple(
                a for a in self.attestation_log
                if a.target == tgt and a.source in justified_before and self.validators[a.validator].is_active)
        return result

    # ---- syncing justification
    def export_proofs(self) -> list[tuple[Attestation, ...]]:
        return [self.proofs[e] for e in sorted(self.proofs)]

    def import_proofs(self, proofs: list[tuple[Attestation, ...]]) -> bool:
        """Verify and adopt justified checkpoints from a peer, oldest first, using Lab 03's own
        justification/finalisation rules against THIS node's balances. True if anything changed."""
        changed = False
        for link in sorted((p for p in proofs if p), key=lambda p: p[0].target.epoch):
            tgt = link[0].target
            if tgt in self.justified:
                continue
            for a in link:
                self.attest(a)
            if self._process_justification(tgt.epoch) == tgt:
                self.proofs[tgt.epoch] = link
                fin_before = self.finalized
                self._process_finalization(self.current_epoch)
                changed = True
                if self.finalized != fin_before:
                    self.last_finalized_epoch = self.current_epoch
                    self.finalized_history.append(self.finalized)
        return changed

    # ---- views used by the engine / metrics
    @property
    def last_justified(self) -> Checkpoint:
        return self.current_justified

    def active_eth(self) -> float:
        return self.total_active_balance / GWEI

    def voting_eth(self, epoch: int) -> float:
        voters = {a.validator for a in self.attestation_log if a.target.epoch == epoch}
        return sum(self.validators[i].effective_balance for i in voters
                   if self.validators[i].is_active) / GWEI

    def leaking(self, epoch: int) -> bool:
        return epoch - self.last_finalized_epoch > pos.MIN_EPOCHS_TO_INACTIVITY_PENALTY


def predict_leak_recovery(validators: int, offline: list[int], first_offline_epoch: int,
                          max_epochs: int = 500) -> dict[str, int]:
    """Network-free prediction with an untouched Lab 03 BeaconState: everyone attests honestly
    until `first_offline_epoch`, then the `offline` validators stop. Returns the epochs at which
    the leak starts, justification returns and finality returns."""
    st = BeaconState(validators, "genesis")
    out: dict[str, int] = {}
    for e in range(1, max_epochs):
        voters = [i for i in range(validators) if e < first_offline_epoch or i not in offline]
        st.attest_many(pos.honest_attestations(st, st.current_justified, Checkpoint(e, f"r{e}"), voters))
        fin_before = st.finalized
        leaking_now = e - st.last_finalized_epoch > pos.MIN_EPOCHS_TO_INACTIVITY_PENALTY
        r = st.process_epoch(e)
        if e >= first_offline_epoch:
            if leaking_now and "leak_starts" not in out:
                out["leak_starts"] = e
            if r["justified"] is not None and "justified_again" not in out:
                out["justified_again"] = e
            if st.finalized != fin_before and "finalized_again" not in out:
                out["finalized_again"] = e
                out["finalized_checkpoint"] = st.finalized.epoch
                return out
        else:
            out["last_finalized_before"] = st.finalized.epoch
    return out
