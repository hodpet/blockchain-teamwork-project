"""The only module that knows Lab 03 (`consensus.chain`) block field names."""
from __future__ import annotations

from typing import Any


def block_hash(b: Any) -> str:
    return b.hash


def block_parent(b: Any) -> str:
    return b.prev_hash


def block_height(b: Any) -> int:
    return b.height


def block_miner(b: Any) -> str:
    return b.miner


def block_timestamp(b: Any) -> float:
    return b.timestamp
